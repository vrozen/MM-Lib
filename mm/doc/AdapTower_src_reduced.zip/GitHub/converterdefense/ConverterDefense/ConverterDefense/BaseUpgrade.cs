﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Misc;

using Phantom.Utils;
using Phantom;
using ConverterDefense.Bases;
using ConverterDefense.Towers;
using ConverterDefense.MMGlueCode;

namespace ConverterDefense.UI
{
    public class BaseUpgrade : Mechanism
    {
        private PCNComponent baseBluePrint = new PCNComponent("Base");

        private EntityLayer entities;

        private List<String> interactiveNodes;

        private static String[] builtinNodes = { "hitByEssence", "hitByCreep", "tick" };

        public BaseUpgrade(EntityLayer entities)
        {
            MainGameState.diagram.bindDefinition(this, "Base");
            this.entities = entities;
            interactiveNodes = new List<String>();
        }

        public Base createBase(Vector2 position, uint instance)
        {
            Base b = (Base) EntityFactory.AssembleEntity(baseBluePrint, "Base");
            b.Position = position;
            Mechanism mechanism = b.GetComponentByType<Mechanism>();
            MainGameState.diagram.bindInstance(mechanism, instance);

            foreach(String nodeName in interactiveNodes)
            {
                UpgradeButton button = new UpgradeButton(mechanism, nodeName);
                UpgradeControl ug = b.GetComponentByType<UpgradeControl>();
                ug.AddComponent(button);
            }

            return b;
        }

        protected override void onNewNode(string nodeName)
        {
            if (builtinNodes.Contains(nodeName) == false)
            {
                if (interactiveNodes.Contains(nodeName) == false)
                {
                    if (MainGameState.diagram.isInteractive(this, nodeName) == true)
                    {
                        interactiveNodes.Add(nodeName);
                        foreach (Base b in entities.GetAllComponentsByType<Base>())
                        {
                            Mechanism m = b.GetComponentByType<Mechanism>();
                            UpgradeButton button = new UpgradeButton(m, nodeName);
                            UpgradeControl ug = b.GetComponentByType<UpgradeControl>();
                            ug.AddComponent(button);
                        }
                    }
                }
            }
        }

        protected override void onDeleteNode(string nodeName)
        {
            if (interactiveNodes.Contains(nodeName))
            {
                interactiveNodes.Remove(nodeName);
            }
            //TODO: remove component from existing bases
            //TODO: make this a generic class
        }
    }
}
