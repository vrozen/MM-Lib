﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework.Graphics;
using Phantom;
using Microsoft.Xna.Framework;
using Phantom.Graphics;
using ConverterDefense.Creeps;

namespace ConverterDefense
{
    public class TrackRenderer : Component
    {
        private RenderTarget2D tracks;
        private GraphicsDevice graphics;
        private SpriteBatch blitter;


        public TrackRenderer()
        {
            this.tracks = new RenderTarget2D(PhantomGame.Game.GraphicsDevice, (int)PhantomGame.Game.Width, (int)PhantomGame.Game.Height, false, SurfaceFormat.Color, DepthFormat.None, 0, RenderTargetUsage.PreserveContents);
            this.graphics = PhantomGame.Game.GraphicsDevice;
            this.blitter = new SpriteBatch(graphics);

            graphics.SetRenderTarget(this.tracks);
            graphics.Clear(Color.Transparent);
            graphics.SetRenderTarget(null);

        }

        public void CreateTrack(Vector2 position, Sprite sprite, int frame, Color color, float alpha)
        {            
            lock (PhantomGame.Game.GlobalRenderLock)
            {
                graphics.SetRenderTarget(this.tracks);
                blitter.Begin(SpriteSortMode.FrontToBack, BlendState.Additive);
                RenderInfo info = new RenderInfo();
                info.Batch = blitter;
                sprite.RenderFrame(info, frame, position, 0, 1, color, alpha);
                blitter.End();
                graphics.SetRenderTarget(null);
            }
        }

        public override void Render(Phantom.Graphics.RenderInfo info)
        {
            base.Render(info);
            if (info.Pass == 0)
                info.Batch.Draw(this.tracks, new Vector2(0,0), Color.White);
        }
    }
}
