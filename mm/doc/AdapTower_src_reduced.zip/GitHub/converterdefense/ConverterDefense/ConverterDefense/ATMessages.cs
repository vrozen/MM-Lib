﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConverterDefense
{
    public static class ATMessages
    {
        public const int Kill = 100000;
        public const int ClickAt = 100100;
        public const int Select = 100101;
        public const int Deselect = 100102;
    }
}
