﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Utils;

using Microsoft.Xna.Framework.Graphics;
using Phantom.Graphics;
using Phantom;
using ConverterDefense.MMGlueCode;
using Phantom.Misc;

namespace ConverterDefense.Towers
{
    public class UpgradeButton : EntityComponent
    {
        public const float Radius = 24;
        public Vector2 Position;
        public float Angle;
        public string Command;
        public float Activated;
        public Mechanism m;
        private UpgradeControl upgradeControl;
        public bool Enabled = true;

        public UpgradeButton(Mechanism m, string command)
        {
            this.m = m; //added by rozen
            this.Command = command;
        }

        public override void OnAdd(Component parent)
        {
            base.OnAdd(parent);
            upgradeControl = parent as UpgradeControl;
            if (upgradeControl == null)
                throw new Exception("UpgradeButton must be added to an UpgradeControl component");
        }

        public override void Update(float elapsed)
        {
            base.Update(elapsed);
            Activated -= Math.Min(Activated, elapsed);
        }

        public override void Render(Phantom.Graphics.RenderInfo info)
        {
            base.Render(info);
            if (info.Pass == info.Renderer.Passes - 1)
            {
                Color c = Color.Lerp(Color.White, Color.Yellow, TweenFunctions.SinoidInOut(Activated));
                if (!Enabled)
                    c = Color.Lerp(Color.White, 0x00004e.ToColor(), 0.7f);

                TowerRenderer.Sprite.RenderFrame(info, 1, this.Position, 0, 1);
                TowerRenderer.Sprite.RenderFrame(info, 2, this.Position, 0, 1, c);


                //TowerRenderer.Sprite.RenderFrame(info, 16, this.Entity.Position, Angle+MathHelper.Pi, 1, c);
                //TowerRenderer.Sprite.RenderFrame(info, 17, this.Entity.Position + this.Position * 0.75f, 0, 1);

                RenderText(info, Command, this.Position, 1.0f, 0x00004e.ToColor());
                //info.Canvas.FillColor = Color.Red;
                //info.Canvas.FillCircle(this.Entity.Position + this.Position, Radius);
            }
        }

        public static void RenderText(RenderInfo info, string text, Vector2 position, float scale, Color color)
        {
            if (text.StartsWith("upgrade"))
            {
                text = text.Substring(7, 3);
            }
            Vector2 size = AdapTower.BasicFont.MeasureString(text);
            info.Batch.DrawString(AdapTower.BasicFont, text, position, color, 0, size * 0.5f, scale, SpriteEffects.None, 0);
        }

        public override void HandleMessage(Message message)
        {
            base.HandleMessage(message);
            if (upgradeControl.Activated)
            {
                switch (message.Type)
                {
                    case ATMessages.ClickAt:
                        if (Enabled)
                        {
                            Vector2 p = (Vector2)message.Data;
                            p = p - (this.Position);
                            if (p.LengthSquared() < Radius * Radius)
                            {
                                Click();
                                message.Consume();
                            }
                        }
                        return;
                }
            }
        }

        private void Click()
        {
            Activated = 1;
            MainGameState.diagram.activate(m, Command);
            //MainGameState.diagram.HandleSignal(this.Entity, Command, 10, null);
        }
    }
}
