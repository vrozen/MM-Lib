﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Phantom;
using Microsoft.Xna.Framework;
using Phantom.Misc;

using ConverterDefense.MMGlueCode;

namespace ConverterDefense.Towers
{
    class Gun : EntityComponent 
    {
        public float range;
        public int targets;
        private float fireRate;
        private float damage;
        private float coolDown;
        private Entity firingAt;
        private float firing;
        public float orientation;
        private Vector2 firingPos;
        private float angle;
        private float length;


        public Gun(float range, float fireRate, float damage)
        {
            this.range = range;
            this.fireRate = fireRate;
            this.damage = damage;
            this.targets = 1;
        }

        public override void Integrate(float elapsed)
        {
            coolDown -= elapsed;
        }

        public void TryFireAt(Entity target)
        {
            if (coolDown <= 0)
            {
                FireAt(target);
                coolDown = 1 / fireRate;
            }
        }

        private void FireAt(Entity target)
        {
            firingAt = target;
            if (PhantomGame.Randy.NextFloat() < damage)
            {
               //target.HandleMessage(ATMessages.Kill, this);

               //Rozen: tell the turret we kill a creep
               Turret t = Parent.GetComponentByType<Turret>();
               t.killCreep(target);
            }
            firing = 1;
            firingPos = this.Entity.Position + 30 * PhantomUtils.FromAngle(orientation);
            Vector2 delta = target.Position - firingPos;
            length = delta.Length();
            angle = (float)Math.Atan2(delta.Y, delta.X);
            firingPos += delta * 0.5f;
        }

        public override void Render(Phantom.Graphics.RenderInfo info)
        {
            if (info.Pass == MainGameState.PassObjects)
            {
                TowerRenderer.Sprite.RenderFrame(info, 3, this.Entity.Position - firing * 4 * PhantomUtils.FromAngle(orientation), orientation);
            }

            if (firingAt != null && info.Pass == MainGameState.PassObjects + 1)
            {
                TowerRenderer.Sprite.RenderFrame(info, 5, firingPos, angle, new Vector2(length * TowerRenderer.Sprite.InverseWidth, 1), Color.White, firing, false);

                //info.Canvas.StrokeColor = Color.Lerp(Color.Transparent, Color.White, firing);
                //info.Canvas.LineWidth = 3;
                //info.Canvas.StrokeLine(Entity.Position, firingAt.Position);
                firing -= info.Elapsed * 5;

                if (firing <= 0)
                    firingAt = null;
            }
        }


        public void setRange(int range)
        {
            this.range = range;
        }

        public void setDamage(int damage)
        {
            this.damage = damage;
        }


    }
}
