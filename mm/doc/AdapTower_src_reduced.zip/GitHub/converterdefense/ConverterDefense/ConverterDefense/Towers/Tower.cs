﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Shapes;
using Phantom.Graphics;

namespace ConverterDefense.Towers
{
    public class Tower : Entity
    {
        public const float Radius = 25;
            
        public Tower()
            : base (new Vector2(0,0))
        {
            AddComponent(new Circle(Radius));
            AddComponent(new TowerRenderer(1));
            AddComponent(new Gun(250, 0.3f, 1.0f));
            AddComponent(new Turret(1f));
            UpgradeControl ug = new UpgradeControl();
            AddComponent(ug);
            //ug.AddComponent(new UpgradeButton("Upgrade1"));
            //ug.AddComponent(new UpgradeButton("Upgrade2"));
            //ug.AddComponent(new UpgradeButton("Upgrade3"));
            Flags |= ATFlags.Tower;
        }
    }
}
