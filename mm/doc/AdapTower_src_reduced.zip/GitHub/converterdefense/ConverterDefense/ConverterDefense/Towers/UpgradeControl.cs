﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Phantom.Shapes;
using Microsoft.Xna.Framework;
using Phantom.Misc;
using Phantom;
using ConverterDefense.MMGlueCode;
using Phantom.Utils;
using ConverterDefense.Bases;

namespace ConverterDefense.Towers
{
    public class UpgradeControl : Mechanism
    {
        private Vector2 infoPosition;
        private Turret turret;
        private ResourceCollector resourceCollector;
        private Gun gun;
        private Dictionary<string, int> values;

        public bool Activated {get; private set;}

        public UpgradeControl()
        {
            Activated = false;
            values = new Dictionary<string, int>();
            CheckControls();
        }

        protected override void OnComponentAdded(Component child)
        {
            base.OnComponentAdded(child);
            CheckControls();
        }

        protected override void OnComponentRemoved(Component child)
        {
            base.OnComponentRemoved(child);
            CheckControls();
        }

        public override void OnAdd(Component parent)
        {
            base.OnAdd(parent);
            turret = parent.GetComponentByType<Turret>();
            gun = parent.GetComponentByType<Gun>();
            resourceCollector = parent.GetComponentByType<ResourceCollector>();
        }

        private void CheckControls()
        {
            infoPosition = new Vector2(PhantomGame.Game.Width * 0.15f, PhantomGame.Game.Height - 80);
            for (int i = 0; i < Components.Count; i++)
            {
                UpgradeButton b = Components[i] as UpgradeButton;
                if (b != null)
                {
                    b.Position = infoPosition;
                    infoPosition.X += UpgradeButton.Radius * 2;
                }
            }
            
        }

        public override void Render(Phantom.Graphics.RenderInfo info)
        {
            if (Activated)
            {
                if (info.Pass==0) {
                    TowerRenderer.Sprite.RenderFrame(info, 56, new Vector2(PhantomGame.Game.Width * 0.10f, PhantomGame.Game.Height - 80));
                    TowerRenderer.Sprite.RenderFrame(info, 58, new Vector2(PhantomGame.Game.Width * 0.90f, PhantomGame.Game.Height - 80));
                    for (float x = PhantomGame.Game.Width * 0.10f + TowerRenderer.Sprite.Width; x < PhantomGame.Game.Width * 0.90; x += TowerRenderer.Sprite.Width)
                    {
                        TowerRenderer.Sprite.RenderFrame(info, 57, new Vector2(x, PhantomGame.Game.Height - 80));
                    }

                    List<string> text = new List<string>();
                    foreach (KeyValuePair<string, int> value in values)
                    {
                        text.Add(value.Key + ": " + value.Value.ToString());
                    }

                    Vector2 pos = infoPosition;
                    pos.Y -= 30;
                    for (int i = 0; i < text.Count; i++)
                    {
                        info.Batch.DrawString(AdapTower.BasicFont, text[i], pos, 0x00004e.ToColor());
                        pos.Y += 19;
                        if (pos.Y > PhantomGame.Game.Height - 70)
                        {
                            pos.Y = PhantomGame.Game.Height - 110;
                            pos.X += 150;
                        }
                    }
                }
                base.Render(info);
            }
        }

        public override void HandleMessage(Message message)
        {
            base.HandleMessage(message);
            switch (message.Type)
            {
                case ATMessages.Select:
                    Activated = true;
                    message.Handle();
                    break;
                case ATMessages.Deselect:
                    Activated = false;
                    message.Handle();
                    break;
            }
        }

        protected override void onAddValue(string nodeName, int value)
        {
            switch(nodeName)
            {
              case "essence":
                    if (turret != null)
                      turret.onAddValue(nodeName, value);
                    break;
            };
        }

        protected override void onSubValue(string nodeName, int value)
        {
            switch (nodeName)
            {
                case "killCreep": //hack: when this tower destroys a creep essence comes from this mechanic
                    //if (turret != null)
                        //turret.onAddValue(nodeName, value);
                    break;
                case "amplify":
                    if (resourceCollector != null)
                        resourceCollector.OnSubValue(nodeName, value);
                    break;
                default:
                    //do nothing
                    break;
            }
        }

        //Micro-Machinations update value
        protected override void onUpdateValue(string nodeName, int value)
        {
            this.values[nodeName] = value;

            switch (nodeName)
            {
                case "self":
                    if (value == 0)
                    {
                        Entity.Destroyed = true;
                    }
                    break;
                case "rotationSpeed":
                    turret.SetRotationSpeed(value);
                    break;
                case "range":
                    gun.setRange(value);
                    break;
                case "firePower":
                    gun.setDamage(value);
                    break;
                default:
                    //no builtin behavior for this node (which might be new)
                    break;
            }
        }

        //TODO Disable and enable something like this
        protected override void onEnableNode(string nodeName)
        {
            foreach (Component c in Components)
            {
                UpgradeButton b = c as UpgradeButton;
                if (b != null)
                {
                    if (b.Command == nodeName)
                    {
                        b.Enabled = true;
                    }
                }
            }
        }

        protected override void onDisableNode(string nodeName)
        {
            foreach (Component c in Components)
            {
                UpgradeButton b = c as UpgradeButton;
                if (b != null)
                {
                    if (b.Command == nodeName)
                    {
                        b.Enabled = false;
                    }
                }
            }
        }

    }
}
