﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Misc;

using Phantom.Utils;
using Phantom;
using ConverterDefense.MMGlueCode;

using ConverterDefense.Creeps;


namespace ConverterDefense.Towers
{
    class Turret : EntityComponent /*EntityComponent, Machinable*/
    {
        private float orientation;
        private float rotationSpeed;
        private EntityLayer entities;
        private Entity target;
        private Gun gun;
        private static float neutralOrientation = -MathHelper.PiOver2;

        //added by rozen
        private PCNComponent essenceBluePrint = new PCNComponent("Essence");
        private Vector2 diedCreepPosition; //position a creep was last killed in

        public Turret(float rotationSpeed)
        {
            this.rotationSpeed = rotationSpeed;
            this.orientation = neutralOrientation;

            target = null;
        }

        public override void OnAncestryChanged()
        {
            base.OnAncestryChanged();
            entities = Entity.Parent as EntityLayer;
            gun = Entity.GetComponentByType<Gun>();
            if (gun == null)
            {
                throw new Exception("Turret expects its parent to have a Gun component.");
            }
        }

        public override void Integrate(float elapsed)
        {
            base.Integrate(elapsed);
            if (target == null)
                FindTarget();
            if (target != null)
                TrackTarget(elapsed);
            else
                ReturnToNeutral(elapsed);
            gun.orientation = orientation;
            
        }

        private void ReturnToNeutral(float elapsed)
        {
            float max = elapsed * rotationSpeed;
            float a = MathHelper.Clamp(PhantomUtils.AngleDifference(orientation, neutralOrientation), -max, max);
            orientation += a;
        }

        private void TrackTarget(float elapsed)
        {
            if (target.Destroyed)
            {
                target = null;
                return;
            }
            Vector2 d = target.Position - Entity.Position;
            if (d.LengthSquared() > gun.range * gun.range)
            {
                target = null;
                return;
            }
            float max = elapsed * rotationSpeed;
            float a = MathHelper.Clamp(PhantomUtils.AngleDifference(orientation, d.Angle()), -max, max);
            orientation += a;
            if (Math.Abs(a) < max)
                gun.TryFireAt(target);
        }

        private void FindTarget()
        {
            float minAngle = float.MaxValue;
            float targetDist = float.MaxValue;
            for (int i = 0; i < entities.Components.Count; i++)
            {
                Entity e = entities.Components[i] as Entity;
                if (e != null && (e.Flags & ATFlags.Creep) > 0 && !e.Destroyed)
                {
                    Vector2 d = e.Position - Entity.Position;
                    float dist = d.LengthSquared();
                    if (dist < gun.range * gun.range)
                    {
                        float a = Math.Abs(PhantomUtils.AngleDifference(orientation, d.Angle()));
                        if (a < minAngle || targetDist>gun.range * gun.range)
                        {
                            target = e;
                            minAngle = a;
                            targetDist = dist;
                        }
                    }
                    else if (targetDist > gun.range * gun.range && dist < gun.range * gun.range * 4)
                    {
                        float a = Math.Abs(PhantomUtils.AngleDifference(orientation, d.Angle()));
                        if (a < minAngle)
                        {
                            target = e;
                            minAngle = a;
                            targetDist = dist;
                        }
                    }
                }
            }

        }

        public override void Render(Phantom.Graphics.RenderInfo info)
        {
            base.Render(info);
            if (info.Pass == MainGameState.PassObjects)
            {

                //Vector2 p = Entity.Position;
                //p.X += (float)Math.Cos(orientation) * 20;
                //p.Y += (float)Math.Sin(orientation) * 20;

                //ConverterDefense.CircleSprite.RenderFrame(info, 0, p, 0, 5 * 2 * ConverterDefense.CircleSprite.InverseWidth, Color.Black);

                TowerRenderer.Sprite.RenderFrame(info, 4, this.Entity.Position, orientation);
            }
        }


        public void killCreep(Entity other)
        {
            diedCreepPosition = other.Position;
            MainGameState.diagram.activate(this.Parent.GetComponentByType<Mechanism>(), "killCreep");
            other.Destroyed = true;
        }


        public override void AfterCollisionWith(Entity other, Phantom.Physics.CollisionData collision)
        {
            if (other is Creep && Entity.Destroyed == false)
            {
                other.Destroyed = true;
                MainGameState.diagram.activate(this.Parent.GetComponentByType<Mechanism>(), "hitByCreep");
            }
        }

        public void setDiedCreepPosition(Vector2 diedCreepPosition)
        {
            this.diedCreepPosition = diedCreepPosition;
        }

        internal void onAddValue(string nodeName, int value)
        {
            float a = PhantomGame.Randy.NextFloat() * MathHelper.TwoPi;
            for (int i = 0; i < value; i++)
            {
                Entity resource = EntityFactory.AssembleEntity(essenceBluePrint, "Essence");
                Vector2 v = new Vector2((float)Math.Cos(a), (float)Math.Sin(a));
                resource.Position = diedCreepPosition + v * 5;
                resource.Mover.Velocity = v * (1 + PhantomGame.Randy.NextFloat() + PhantomGame.Randy.NextFloat()) * 40;
                a += MathHelper.TwoPi / value;
                entities.AddComponent(resource);
            }
        }

        internal void SetRotationSpeed(int value)
        {
            rotationSpeed = MathHelper.ToRadians(30+value);
        }
    }
}
