﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Shapes;
using Phantom.Graphics;
using ConverterDefense.Towers;

namespace ConverterDefense.Bases
{
    public class Base : Entity
    {
        public const float Radius = 20;

        public Base()
            : base(new Vector2(0, 0))
        {
            AddComponent(new Circle(Radius));
            AddComponent(new BaseRenderer());
            AddComponent(new ResourceCollector());
            AddComponent(new UpgradeControl());
            Flags |= ATFlags.Base;
        }
    }
}
