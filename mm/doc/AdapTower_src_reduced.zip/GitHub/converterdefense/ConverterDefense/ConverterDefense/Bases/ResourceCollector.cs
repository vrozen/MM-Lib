﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using ConverterDefense.Resources;
using ConverterDefense.MMGlueCode;

using Phantom.Utils;
using Phantom;
using Phantom.Misc;
using ConverterDefense.Creeps;

using Microsoft.Xna.Framework;

namespace ConverterDefense.Bases
{
    public class ResourceCollector : EntityComponent 
    {
        private PCNComponent essenceBluePrint = new PCNComponent("Essence");

        private EntityLayer entities;

        private Vector2 essencePos = Vector2.Zero;

        public override void OnAncestryChanged()
        {
            base.OnAncestryChanged();
            entities = Entity.Parent as EntityLayer;
        }

        public override void AfterCollisionWith(Entity other, Phantom.Physics.CollisionData collision)
        {
            //base.AfterCollisionWith(other, collision);
            
            if (other is Creep)
            {
                MainGameState.diagram.activate(this.Parent.GetComponentByType<Mechanism>(), "hitByCreep");
                other.Destroyed = true;
            }
            else if (other is Essence)
            {
                MainGameState.diagram.activate(this.Parent.GetComponentByType<Mechanism>(), "hitByEssence");
                other.Destroyed = true;

                this.essencePos = other.Position;
            }
            else
            {
                Console.WriteLine("BLA");
            }
            //Resource r = other.GetComponentByType<Resource>();
            //if (r != null)
            //{
                //This is not correct yet:
                //MainGameState.diagram.HandleSignal("CollectGold", 10, other);

                //we need to activate the "hitByEssence" node in the instance of this base
            //    MainGameState.diagram.activate(this, "hitByEssence");
            //}
        }




        internal void OnSubValue(string nodeName, int value)
        {
            EntityFactory.AssembleEntity(essenceBluePrint, "Essence");


            float a = PhantomGame.Randy.NextFloat() * MathHelper.TwoPi;
            for (int i = 0; i < value; i++)
            {
                Entity resource = EntityFactory.AssembleEntity(essenceBluePrint, "Essence");
                Vector2 v = new Vector2((float)Math.Cos(a), (float)Math.Sin(a));
                resource.Position = Entity.Position + new Vector2(0, 50);
                resource.Mover.Velocity = v * (1 + PhantomGame.Randy.NextFloat() + PhantomGame.Randy.NextFloat()) * 40;
                a += MathHelper.TwoPi / value;
                entities.AddComponent(resource);
            }
        }
    }

}
