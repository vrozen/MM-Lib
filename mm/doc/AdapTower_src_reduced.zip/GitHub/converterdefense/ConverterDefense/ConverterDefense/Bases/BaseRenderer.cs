﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Shapes;
using Phantom.Graphics;
using Phantom;
using Microsoft.Xna.Framework.Graphics;

namespace ConverterDefense.Bases
{
    public class BaseRenderer : EntityComponent
    {
        public static Sprite Sprite = new Sprite(PhantomGame.Game.Content.Load<Texture2D>("sprites/towers"), 80, 80);
        private int frame;
        private float bounce;
        private float timer;
        private bool selected;


        public BaseRenderer()
            : this(8) { }

        public BaseRenderer(int frame)
        {
            this.frame = frame;
        }

        public override void Update(float elapsed)
        {
            base.Update(elapsed);
            bounce -= Math.Min(elapsed, bounce);
            timer += elapsed;
        }

        public override void AfterCollisionWith(Entity other, Phantom.Physics.CollisionData collision)
        {
            base.AfterCollisionWith(other, collision);
            bounce = 1;
        }

        public override void Render(Phantom.Graphics.RenderInfo info)
        {
            base.Render(info);
            if (info.Pass == MainGameState.PassObjects)
            {
                Vector2 scaleV = new Vector2(1 + bounce * 0.04f * (float)Math.Cos(timer * 15), 1 - bounce * 0.04f * (float)Math.Cos(timer * 15));
                Sprite.RenderFrame(info, frame, this.Entity.Position, 0, scaleV, Color.White, 1, false);
                scaleV = new Vector2(1 + bounce * 0.02f * (float)Math.Cos(timer * 15), 1 - bounce * 0.02f * (float)Math.Cos(timer * 15));
                Sprite.RenderFrame(info, frame + 1, this.Entity.Position, 0, scaleV, selected? Color.Yellow : Color.White, 1, false);
                Sprite.RenderFrame(info, frame + 2, this.Entity.Position, timer*0.2f);
                Sprite.RenderFrame(info, frame + 3, this.Entity.Position, timer*-0.2f);
                //Sprite.RenderFrame(info, frame + 1, this.Entity.Position);
            }
        }

        public override void HandleMessage(Message message)
        {
            base.HandleMessage(message);
            switch (message.Type)
            {
                case ATMessages.Select:
                    selected = true;
                    message.Handle();
                    break;
                case ATMessages.Deselect:
                    selected = false;
                    message.Handle();
                    break;
            }
        }

    }
}
