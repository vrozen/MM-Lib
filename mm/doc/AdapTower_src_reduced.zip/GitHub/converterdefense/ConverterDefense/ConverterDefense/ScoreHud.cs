﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom;
using Phantom.Graphics;
using ConverterDefense.Resources;

namespace ConverterDefense.UI
{
    public class ScoreHud : Component
    {
        private MainGameState game;
        private float timer;

        public ScoreHud(MainGameState game)
        {
            this.game = game;
        }

        public override void Render(RenderInfo info)
        {
            base.Render(info);
            if (info.Pass == info.Renderer.Passes - 1)
            {
                timer += info.Elapsed;
                RenderText(info, "Bases", new Vector2(PhantomGame.Game.Width * 0.5f, 20), 1.0f, AdapTower.ScoreColor, AdapTower.ShadowColor);
                RenderText(info, game.Bases.ToString(), new Vector2(PhantomGame.Game.Width * 0.5f, 50), 1.0f, AdapTower.ScoreColor, AdapTower.ShadowColor);
                RenderText(info, "Score", new Vector2(PhantomGame.Game.Width * 0.1f, 20), 1.0f, AdapTower.ScoreColor, AdapTower.ShadowColor);
                RenderText(info, MainGameState.LastScore.ToString(), new Vector2(PhantomGame.Game.Width * 0.1f, 50), 1.0f, AdapTower.ScoreColor, AdapTower.ShadowColor);
                RenderText(info, "High Score", new Vector2(PhantomGame.Game.Width * 0.9f, 20), 1.0f, AdapTower.ScoreColor, AdapTower.ShadowColor);
                RenderText(info, MainGameState.BestScore.ToString(), new Vector2(PhantomGame.Game.Width * 0.9f, 50), 1.0f, AdapTower.ScoreColor, AdapTower.ShadowColor);
                //RenderText(info, "Gold", new Vector2(PhantomGame.Game.Width * 0.5f, PhantomGame.Game.Height - 20), 1.0f, ConverterDefense.GoldColor, ConverterDefense.GoldShadowColor);
                Resource.RenderCoin(info, new Vector2(PhantomGame.Game.Width * 0.5f - 50, PhantomGame.Game.Height - 20), 0, ((timer * -1.2f) % 2) + 2, 0);
                Resource.RenderCoin(info, new Vector2(PhantomGame.Game.Width * 0.5f + 50, PhantomGame.Game.Height - 20), 0, ((timer * 1.2f) % 2), 0);
                RenderText(info, game.Gold.ToString(), new Vector2(PhantomGame.Game.Width * 0.5f, PhantomGame.Game.Height - 20), 1.0f, AdapTower.GoldColor, AdapTower.GoldShadowColor);
            }
        }

        public static void RenderText(RenderInfo info, string text, Vector2 position, float scale, Color color, Color shadow)
        {
            Vector2 size = AdapTower.HudFont.MeasureString(text);
            info.Batch.DrawString(AdapTower.HudFont, text, position+Vector2.One*2, shadow, 0, size * 0.5f, scale, SpriteEffects.None, 0);
            info.Batch.DrawString(AdapTower.HudFont, text, position, color, 0, size * 0.5f, scale, SpriteEffects.None, 0);
        }
    
    }
}
