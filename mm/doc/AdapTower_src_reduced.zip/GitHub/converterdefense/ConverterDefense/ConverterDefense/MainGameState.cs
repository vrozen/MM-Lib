﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Phantom.Graphics;
using Phantom.Physics;
using ConverterDefense.Creeps;
using ConverterDefense.Towers;
using System.Diagnostics;
using Phantom.GameUI;
using Microsoft.Xna.Framework;
using Phantom;
using Phantom.Shapes;
using ConverterDefense.UI;
using LibMM;
using System.Runtime.InteropServices;
using ConverterDefense.MMGlueCode;
using Phantom.Utils;
using Phantom.Utils.Performance;
using Phantom.Graphics.Components;
using Phantom.Misc;
using Microsoft.Xna.Framework.Graphics;

using ConverterDefense.Underwater;

namespace ConverterDefense
{

    public class MainGameState : GameState /*, Machinable*/
    {
        public static int PassObjects = 0;

        //added by rozen
        public static string ModelDir;

        private int creepTimer = 0;

        private float timer = 1;

        private EntityLayer entities;
        public static Diagram diagram;

        public int Bases = 0;
        public int Gold = 0;
        public static int BestScore = 0;
        public static int LastScore = 0;

        private bool underWater = false;

        public TrackRenderer Tracks;

        public MainGameState()
        {
            //calculate diagrams path
            String path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
            //int index = p.LastIndexOf("ConverterDefense");
            //String path = p.Substring(0, index);
            int len = "file:\\".Length;
            path = path.Substring(len, path.Length - len);
            ModelDir = path + "\\Content\\diagrams\\";

            Console.WriteLine("Models directory: " + ModelDir);
            

            entities = new EntityLayer(new Renderer(2, Renderer.ViewportPolicy.Fit, Renderer.RenderOptions.Canvas), new TiledIntegrator(1, 40));
            AddComponent(entities);

            //create new diagram
            diagram = new Diagram(entities);

            //add modifications to the diagram
            diagram.addModel(ModelDir + "mod1_fig7_tower1.mm");
            diagram.addModel(ModelDir + "mod2_fig8_base1.mm");
            diagram.addModel(ModelDir + "mod3_fig6_world.mm");

            for (int mod = 0; mod < 3; mod++)
            {
                diagram.evalNext();
            }

            TowerUpgrade towerFactory = new TowerUpgrade(entities);
            BaseUpgrade baseFactory = new BaseUpgrade(entities);

            AddComponent(towerFactory);
            AddComponent(baseFactory);

            entities.AddComponent(new Image(new Sprite(PhantomGame.Game.Content.Load<Texture2D>("sprites/at_background2"))));
            entities.AddComponent(this.Tracks = new TrackRenderer());
            //AddComponent(new WaveManager());
            AdapTowerUI ui;
            AddComponent(ui = new AdapTowerUI(this, towerFactory, baseFactory, entities));
            entities.AddComponent(new ScoreHud(this));


            /*
            diagram.addModel(ModelDir + "mod4_fig9_tower2.mm");
            diagram.addModel(ModelDir + "mod6_fig11_tower3.mm");
            diagram.addModel(ModelDir + "mod8_fig13_tower4.mm");
            */

            diagram.addModel(ModelDir + "mod4_agd_v2.mm");
            diagram.addModel(ModelDir + "mod5_agd_v3.mm");
            diagram.addModel(ModelDir + "mod6_agd_hitpoints.mm");
            diagram.addModel(ModelDir + "mod7_agd_firerate.mm");
            diagram.addModel(ModelDir + "mod8_agd_sell.mm");
            diagram.addModel(ModelDir + "mod9_agd_soulreap.mm");
            diagram.addModel(ModelDir + "mod10_agd_radius.mm");

            //evaluate all modifications: note, we actually want to do it one by one.
            //while (diagram.hasNextModification())
           // {
            //    diagram.evalNext();
            //}

            //Trace.WriteLine(diagram.getModel());

            //string diagram = System.IO.File.ReadAllText(@"Content\diagrams\simple_mm.txt");
            //Diagram = new MMDiagram(entities, diagram);
            //Diagram = new MMDiagram(entities, "C:\\Users\\rozen\\Documents\\cs\\converterdefense\\ConverterDefense\\ConverterDefense\\bin\\x86\\Debug\\Content\\diagrams\\test.mm");




            //Diagram = new FauxDiagram(entities);
            //diagram.BindElement(new MMBinding("Bases", "Base"));
            //diagram.BindElement(new MMBinding("Towers", "Tower"));
            //diagram.BindElement(new MMBinding("Creeps", "Creep"));
            //diagram.BindElement(new MMBinding("Essence", "Essence"));
            //Diagram.Game = this;

            //diagram.bindGlobalInstance(this);

            LastScore = 0;
        }

        
       /*
        public uint mm_getInstance()
        {
            return instance;
        }

        public void mm_setInstance(uint instance)
        {
            this.instance = instance;
        }

        public void mm_update(LibMM.MESSAGE msg, String nodeName, int value)
        {
            switch (msg)
            {
                case MESSAGE.MSG_HAS_VALUE:
                    switch (nodeName)
                    {
                        case "gold":
                            Gold = value;
                            break;
                        case "bases":
                            Bases = value;
                            break;
                        default:
                            break;
                    }
                    break;
                case MESSAGE.MSG_ADD_VALUE:
                    switch (nodeName)
                    {
                        //in this case we create creep entities randomly when creeps spawn
                        case "creeps":
                          Entity e = EntityFactory.AssembleEntity(creepBlueprint, "Creep");
                          entities.AddComponent(e);
                          break;
                    }
                    break;
                default:
                    break;
            }
        }
        */

        public void goUnderWater()
        {
            this.underWater = true;
        }

        public override void Update(float elapsed)
        {
            base.Update(elapsed);
            timer -= elapsed;
            if (timer < 0)
            {
                if (creepTimer == 25)
                {
                    //spawn
                    diagram.activate("spawn");
                    creepTimer = 0;
                }

                creepTimer++;
                timer += 0.1f;

                //diagram.step();

                if (underWater == true)
                {
                    underWater = false;
                    PhantomGame.Game.PushState(new UnderwaterScreen());
                }
            }
        }

        public void ChangeBases(int delta)
        {
            Bases += delta;
            LastScore = Math.Max(Bases, LastScore);
            BestScore = Math.Max(BestScore, LastScore);
        }
    }
}
