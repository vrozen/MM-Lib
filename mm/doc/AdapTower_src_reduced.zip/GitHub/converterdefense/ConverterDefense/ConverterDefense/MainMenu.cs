﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework.Input;
using Phantom;
using Phantom.Graphics;
using Phantom.Utils;
using System.Diagnostics;

namespace ConverterDefense
{
    public class MainMenu : GameState
    {
        private MouseState previous;
        public MainMenu()
        {
            AddComponent(new MenuRenderer());
        }

        public override void BackOnTop()
        {
            base.BackOnTop();
            previous = Mouse.GetState();
        }

        public override void Update(float elapsed)
        {
            base.Update(elapsed);
            MouseState current = Mouse.GetState();

            if (current.LeftButton == ButtonState.Pressed && previous.LeftButton != ButtonState.Pressed)
            {
                //calculate diagrams path
                String path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
                //int index = p.LastIndexOf("ConverterDefense");
                //String path = p.Substring(0, index);
                int len = "file:\\".Length;
                path = path.Substring(len, path.Length - len);
                String ModelDir = path + "\\Content\\diagrams\\";
                Trace.WriteLine("Models directory: " + ModelDir);
                Trace.Flush();

                PhantomGame.Game.PushState(new MainGameState());
            }
            previous = current;
        }
    }
}
