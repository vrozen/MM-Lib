﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.GameUI;
using Phantom.Core;
using Microsoft.Xna.Framework;
using ConverterDefense.MMGlueCode;
using Phantom;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;
using Microsoft.Xna.Framework.Graphics;

namespace ConverterDefense.Underwater
{
    public class MMCurrentDiagram : Component
    {
        string model;
        string[] lines;
        public int Line = 0;
        private static SpriteFont font = PhantomGame.Game.Content.Load<SpriteFont>("console");

        private MouseState previous;

        public MMCurrentDiagram()
        {
            UpdateModel();
        }

        public void UpdateModel()
        {
            model = MainGameState.diagram.getModel();
            lines = model.Split('\n');
            Line = 0;
        }

        public override void OnAdd(Component parent)
        {
            base.OnAdd(parent);
            previous = Mouse.GetState();
        }

        public override void Render(Phantom.Graphics.RenderInfo info)
        {
            base.Render(info);
            Vector2 pos = new Vector2(230, 10);
            info.Batch.DrawString(UILayer.Font, "Current Diagram", pos, Color.Yellow);
            pos.Y += UILayer.Font.LineSpacing;

            for (int i = Line; i < lines.Length; i++)
            {
                info.Batch.DrawString(font, lines[i], pos, Color.White);

                pos.Y += font.LineSpacing;
                if (pos.Y>PhantomGame.Game.Height-80)
                    break;
            }
        }

        public override void Update(float elapsed)
        {
            base.Update(elapsed);
            MouseState current = Mouse.GetState();
            int delta =current.ScrollWheelValue - previous.ScrollWheelValue;
            Line -= delta/40;
            if (Line < 0) 
                Line = 0;
            if (Line > lines.Length)
                Line = lines.Length;

            previous = current;
        }
    }
}
