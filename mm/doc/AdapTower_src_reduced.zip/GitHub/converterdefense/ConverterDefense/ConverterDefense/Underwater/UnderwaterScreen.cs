﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Phantom.GameUI;
using Phantom.Graphics;
using Microsoft.Xna.Framework;
using Phantom;
using Phantom.Shapes;

namespace ConverterDefense.Underwater
{
    public class UnderwaterScreen : GameState
    {
        private Button buttonNext;
        private Button buttonEval;
        private MMCurrentDiagram current;
        public UnderwaterScreen()
        {
            UILayer ui = new UILayer(new Renderer(1, Renderer.ViewportPolicy.Fit, Renderer.RenderOptions.Canvas), 1);
            AddComponent(ui);
            ui.AddComponent(new UIMouseHandler());
            ui.AddComponent(new Button("close", "Close", new Vector2(PhantomGame.Game.Width - 50, PhantomGame.Game.Height - 30), new OABB(new Vector2(40, 20))));
            ui.AddComponent(buttonNext = new Button("next", "Next", new Vector2(50, PhantomGame.Game.Height - 30), new OABB(new Vector2(40, 20))));

            ui.AddComponent(buttonEval = new Button("eval", "eval.mm", new Vector2(PhantomGame.Game.Width / 2, PhantomGame.Game.Height - 30), new OABB(new Vector2(40, 20))));

            ui.AddComponent(new MMDiagramList());
            ui.AddComponent(current = new MMCurrentDiagram());
            buttonNext.Enabled = MainGameState.diagram.hasNextModification();
        }

        public override void HandleMessage(Message message)
        {
            base.HandleMessage(message);
            switch (message.Type)
            {
                case Messages.UIElementClicked:
                    if (message.Data is UIElement)
                    {
                        string name = ((UIElement)message.Data).Name;
                        if (name == "close")
                        {
                            PhantomGame.Game.PopState();
                        }
                        else if (name == "next")
                        {
                            MainGameState.diagram.evalNext();
                            buttonNext.Enabled = MainGameState.diagram.hasNextModification();
                            current.UpdateModel();
                        }
                        else if (name == "eval")
                        {
                            MainGameState.diagram.evalModel(MainGameState.ModelDir + "eval.mm");
                            current.UpdateModel();
                        }
                    }
                    break;
            }
        }
    }
}
