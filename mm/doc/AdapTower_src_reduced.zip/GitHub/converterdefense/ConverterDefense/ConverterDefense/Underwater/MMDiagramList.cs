﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.GameUI;
using Phantom.Core;
using Microsoft.Xna.Framework;
using ConverterDefense.MMGlueCode;
using Phantom;
using Phantom.Misc;

namespace ConverterDefense.Underwater
{
    public class MMDiagramList : Component
    {
        public MMDiagramList()
        {

        }

        public override void OnAdd(Component parent)
        {
            base.OnAdd(parent);
            
        }

        public override void Render(Phantom.Graphics.RenderInfo info)
        {
            base.Render(info);
            Vector2 pos = new Vector2(10, 10);
            info.Batch.DrawString(UILayer.Font, "Available Diagrams", pos, Color.Yellow);
            pos.Y += UILayer.Font.LineSpacing;

            for (int i = 0; i < MainGameState.diagram.modifications.Count; i++)
            {
                string t = MainGameState.diagram.modifications[i];
                if (t.LastIndexOf('\\')>=0)
                    t = t.Substring(t.LastIndexOf('\\')+1);
                if (i == MainGameState.diagram.curModification)
                {
                    info.Canvas.FillColor = Color.LightBlue;
                    info.Canvas.FillRect(pos + new Vector2(100, UILayer.Font.LineSpacing * 0.5f), new Vector2(105, UILayer.Font.LineSpacing * 0.5f), 0);
                    info.Batch.DrawString(UILayer.Font, t, pos, 0x123456.ToColor());
                }
                else
                    info.Batch.DrawString(UILayer.Font, t, pos, Color.White);

                pos.Y += UILayer.Font.LineSpacing;
            }
            
        }
    }
}
