﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConverterDefense
{
    public static class ATFlags
    {
        public const uint Tower = 1;
        public const uint Base = 1 << 1;
        public const uint Creep = 1 << 2;
        public const uint Resource = 1 << 3;
    }
}
