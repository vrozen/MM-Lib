using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Phantom;
using Phantom.Misc;
using System.Reflection;
using System.Diagnostics;
using Phantom.Utils;
using Phantom.Graphics;
using Phantom.GameUI;
using Phantom.Utils.Performance;

namespace ConverterDefense
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class AdapTower : PhantomGame
    {
        public static Sprite CircleSprite;
        public static SpriteFont BasicFont;
        public static SpriteFont HudFont;

        public static Color Black = 0x000000.ToColor();
        public static Color ShadowColor = 0x00004e.ToColor();
        public static Color ScoreColor = 0xffffff.ToColor();
        public static Color GoldColor = 0xffdd56.ToColor();
        public static Color GoldShadowColor = 0x5c4620.ToColor();

        public AdapTower()
            : base(800, 600, "AdapTower")
        {
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
            KonsoulSettings settings = new KonsoulSettings();
            settings.EchoLines = 0;
            this.AddComponent(new Konsoul(PhantomGame.Game.Content.Load<SpriteFont>("console"), settings));
            
            Profiler.font = PhantomGame.Game.Content.Load<SpriteFont>("console");
            //Register the components and entities of the game
            EntityFactory.AddTypes(Assembly.GetAssembly(typeof(AdapTower)));
            //Register the components and entities of the phantom library
            EntityFactory.AddTypes(Assembly.GetAssembly(typeof(PhantomGame)));

            CircleSprite = new Sprite(PhantomGame.Game.Content.Load<Texture2D>("sprites/circles"), 256, 256);
            BasicFont = PhantomGame.Game.Content.Load<SpriteFont>("fonts/base");
            HudFont = PhantomGame.Game.Content.Load<SpriteFont>("fonts/hud");
            
            UILayer.Font = BasicFont;

            this.PushState(new MainMenu());

            PhantomGame.XnaGame.IsMouseVisible = true;
        }
    }
}
