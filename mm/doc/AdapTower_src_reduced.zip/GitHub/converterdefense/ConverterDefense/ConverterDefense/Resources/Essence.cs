﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Shapes;
using Phantom;
using Phantom.Misc;

namespace ConverterDefense.Resources
{
    public class Essence : Entity
    {
        public Essence()
            : base(new Vector2(PhantomGame.Game.Resolution.Width + 30, (PhantomGame.Randy.NextFloat() * 0.5f + 0.25f) * PhantomGame.Game.Resolution.Height))
        {
            AddComponent(new Resource("Essence", 1f));
            AddComponent(new Circle(10));
            AddComponent(new Mover(new Vector2(0, 0), 0.5f, 0, 1));
            Flags |= ATFlags.Resource;
        }

        public override void Update(float elapsed)
        {
            base.Update(elapsed);
            if (Position.Y > PhantomGame.Game.Height + 10 && !Destroyed)
            {
                MainGameState.diagram.activate("missed");
                Destroyed = true;
            }
        }
    }
}
