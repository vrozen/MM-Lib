﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Shapes;
using Microsoft.Xna.Framework;
using Phantom.Core;
using Phantom;
using Phantom.Misc;
using ConverterDefense.MMGlueCode;
using Phantom.Graphics;
using Microsoft.Xna.Framework.Graphics;

namespace ConverterDefense.Resources
{
    public enum ResourceType { Gold, Essence }

    public class Resource : EntityComponent
    {
        private static Sprite Sprite = new Sprite(PhantomGame.Game.Content.Load<Texture2D>("sprites/hva_coin"), 32, 32);
        public ResourceType Type;
        private Circle shape;
        private int value;
        private float gravity = 500;
        private float zOrientation;
        private float rotation;
        private float zRotation;
        private int frame;

        public Resource(string type, float value)
        {
            this.Type = (ResourceType)Enum.Parse(typeof(ResourceType), type, true);
            this.value = (int)value;
            zOrientation = PhantomGame.Randy.Next(2);
            rotation = PhantomGame.Randy.NextFloat() - PhantomGame.Randy.NextFloat() * 15;
            zRotation = PhantomGame.Randy.NextFloat() - PhantomGame.Randy.NextFloat() * 5;
            switch (Type)
            {
                case ResourceType.Gold:
                    frame = 0;
                    break;
                case ResourceType.Essence:
                    frame = 12;
                    break;
            }
        }

        public override void OnAdd(Component parent)
        {
            base.OnAdd(parent);
            shape = Entity.Shape as Circle;
            if (shape == null)
            {
                shape = new Circle(10);
                Entity.AddComponent(shape);
            }
            if (Entity.Mover == null)
                Entity.AddComponent(new Mover(new Vector2(0, 0), 0.5f, 0, 1));
            //Default position (somewhere on the right edge of the screen
            Entity.Position = new Vector2(PhantomGame.Game.Resolution.Width + 30, (PhantomGame.Randy.NextFloat() * 0.5f + 0.25f) * PhantomGame.Game.Resolution.Height);
        }

        public override void Integrate(float elapsed)
        {
            base.Integrate(elapsed);
            Entity.Mover.Velocity.Y += gravity * elapsed;
            if (Entity.Position.Y > PhantomGame.Game.Resolution.Height + 10 && Entity.Destroyed != true)
            {
                //MainGameState.diagram.HandleSignal("RemoveEssence", 3, this.Entity);

                //MainGameState.diagram.activate(this, "missed");
            }


            this.Entity.Orientation += rotation * elapsed;
            rotation *= 0.99f;
            this.zOrientation += zRotation * elapsed;
            zRotation *= 0.99f;
        }

        public override void AfterCollisionWith(Entity other, Phantom.Physics.CollisionData collision)
        {
            base.AfterCollisionWith(other, collision);
            float r = PhantomGame.Randy.NextFloat() * 4 + 4;
            if (PhantomGame.Randy.Next(2) == 0)
                r *= -1;
            rotation += r;
            r = PhantomGame.Randy.NextFloat() * 2 + 2;
            if (PhantomGame.Randy.Next(2) == 0)
                r *= -1;
            zRotation += r;
        }



        public override void Render(Phantom.Graphics.RenderInfo info)
        {
            base.Render(info);
            if (info.Pass == MainGameState.PassObjects)
            {
                //ConverterDefense.CircleSprite.RenderFrame(info, 0, Entity.Position, 0, shape.Radius * 2 * ConverterDefense.CircleSprite.InverseWidth, color);
                //ConverterDefense.CircleSprite.RenderFrame(info, 2, Entity.Position, 0, shape.Radius * 2 * ConverterDefense.CircleSprite.InverseWidth, Color.Lerp(color, Color.Black, 0.5f));
                RenderCoin(info, this.Entity.Position, this.Entity.Orientation, zOrientation, frame);
            }
        }

        public static void RenderCoin(RenderInfo info, Vector2 position, float orientation, float zOrientation, int frame)
        {
            zOrientation = ((zOrientation%2)+2)%2;
            if (zOrientation==0) 
                Sprite.RenderFrame(info, 0, position, orientation, 1);
            else if (zOrientation==1)
                Sprite.RenderFrame(info, 1, position, orientation, 1);
            else if (zOrientation < 1)
            {
                float w = (float)Math.Sin(zOrientation * MathHelper.Pi);
                w = Math.Abs(w);
                float iw = 1 - w;
                if (zOrientation > 0.5f)
                    iw *= -1;
                Sprite.RenderFrame(info, frame + 3, position - new Vector2(iw * 3, 0).RotateBy(orientation), orientation, new Vector2(w, 1), Color.White, 1, false);
                Sprite.RenderFrame(info, frame + 2, position, orientation, new Vector2(Math.Abs(iw), 1), Color.White, 1, false);
                Sprite.RenderFrame(info, frame + 0, position + new Vector2(iw * 3, 0).RotateBy(orientation), orientation, new Vector2(w, 1), Color.White, 1, false);
            }
            else 
            {
                float w = (float)Math.Sin(zOrientation * MathHelper.Pi);
                w = Math.Abs(w);
                float iw = 1 - w;
                if (zOrientation > 1.5f)
                    iw *= -1;
                Sprite.RenderFrame(info, frame + 3, position - new Vector2(iw * 3, 0).RotateBy(orientation), orientation, new Vector2(w, 1), Color.White, 1, false);
                Sprite.RenderFrame(info, frame + 2, position, orientation, new Vector2(Math.Abs(iw), 1), Color.White, 1, false);
                Sprite.RenderFrame(info, frame + 1, position + new Vector2(iw * 3, 0).RotateBy(orientation), orientation, new Vector2(w, 1), Color.White, 1, false);
            }

        }
    }
}
