﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using ConverterDefense.Resources;
using Phantom;
using Microsoft.Xna.Framework;
using Phantom.Misc;
using ConverterDefense.MMGlueCode;

using ConverterDefense.Towers;

namespace ConverterDefense.Creeps
{
    class ConvertToResource : EntityComponent
    {
        public ConvertToResource()
        {
        }

        /*
        public override void HandleMessage(Message message)
        {
            switch (message.Type)
            {
                case ATMessages.Kill:
                    if (!Entity.Destroyed)
                    {
                        //SpawnResources(MainGameState.diagram.HandleSignal("KillCreep", 10, Entity));
                        Turret t = ((Component)message.Data).Parent.GetComponentByType<Turret>();
                        t.setDiedCreepPosition(Entity.Position);
                        MainGameState.diagram.activate(t, "killCreep");
                        Entity.Destroyed = true;
                    }
                    break;
            }
            base.HandleMessage(message);
        }*/

        /*
        private void SpawnResources(Entity[] resources)
        {
            float a = PhantomGame.Randy.NextFloat() * MathHelper.TwoPi;
            for (int i = 0; i < resources.Length; i++)
            {
                Vector2 v = new Vector2((float)Math.Cos(a), (float)Math.Sin(a));
                resources[i].Position = this.Entity.Position + v * 5;
                resources[i].Mover.Velocity = v * (1 + PhantomGame.Randy.NextFloat() + PhantomGame.Randy.NextFloat()) * 40;
                a += MathHelper.TwoPi / resources.Length;
            }
        }*/
    }
}
