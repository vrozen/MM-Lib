﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Shapes;
using Phantom.Misc;

namespace ConverterDefense.Creeps
{
    public class Creep : Entity
    {
        public Creep()
            : base(new Vector2(0, 0))
        {
            AddComponent(new Circle(25f));
            AddComponent(new CreepRenderer(0x00ff00.ToColor()));
            AddComponent(new CreepMover(20f, 0.5f));
            AddComponent(new ConvertToResource());
            AddComponent(new DestroyInBase());
            Flags |= ATFlags.Creep;
        }

    }
}