﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using ConverterDefense.Bases;
using ConverterDefense.MMGlueCode;
using Phantom;

namespace ConverterDefense.Creeps
{
    class DestroyInBase : EntityComponent
    {
        public override void Update(float elapsed)
        {
            base.Update(elapsed);
            if (Entity.Position.Y > PhantomGame.Game.Height + 10 && !Entity.Destroyed)
            {
                //MainGameState.diagram.HandleSignal("killCreep", 1, Entity);

                MainGameState.diagram.activate("escape");
                Entity.Destroyed = true;

                //Kill the game too! NOOOOOOOOO
                //PhantomGame.Game.PopState();
            }

        }

        /*
        public override void AfterCollisionWith(Entity other, Phantom.Physics.CollisionData collision)
        {
            base.AfterCollisionWith(other, collision);
            if ((other.Flags & ATFlags.Base) > 0)
            {
               // MainGameState.diagram.HandleSignal(other, "hitByCreep", 3, Entity, other);
            }
            if ((other.Flags & ATFlags.Tower) > 0)
            {
               // MainGameState.diagram.HandleSignal(other, "hitByCreep", 3, Entity, other);
            }
        }*/
    }
}
