﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Shapes;
using Phantom.Graphics;
using Phantom;
using Microsoft.Xna.Framework.Graphics;
using Phantom.Misc;

namespace ConverterDefense.Creeps
{
    class CreepRenderer : EntityComponent
    {
        public static Sprite Sprite = new Sprite(PhantomGame.Game.Content.Load<Texture2D>("sprites/towers"), 80, 80);
        private Color color;
        private Circle shape;
        private float cycle;
        private float blink;
        private Vector2[] eyes;
        private Vector3[] details;
        public CreepRenderer(Color color)
        {
            this.color = color;
            cycle = PhantomGame.Randy.NextFloat() * 100;
            blink = PhantomGame.Randy.NextFloat() * 3;
            eyes = new Vector2[PhantomGame.Randy.Next(3) + 1];
            details = new Vector3[PhantomGame.Randy.Next(2) + 3];

            float r = PhantomGame.Randy.NextFloat()*100;
            for (int i = 0; i < details.Length; i++)
            {
                details[i] = new Vector3(0, 0, 0);
                details[i].X = (float)Math.Cos(r) * (PhantomGame.Randy.NextFloat() + PhantomGame.Randy.NextFloat()) * 5;
                details[i].Y = (float)Math.Sin(r) * (PhantomGame.Randy.NextFloat() + PhantomGame.Randy.NextFloat()) * 5;
                details[i].Z = (PhantomGame.Randy.NextFloat() + PhantomGame.Randy.NextFloat()) * 0.1f+0.8f;
                r += MathHelper.TwoPi / details.Length + (PhantomGame.Randy.NextFloat() - PhantomGame.Randy.NextFloat()) * 0.3f;
            }

            r = PhantomGame.Randy.NextFloat() * 100;
            for (int i = 0; i < eyes.Length; i++)
            {
                eyes[i] = new Vector2(0, 0);
                eyes[i].X = (float)Math.Cos(r) * (PhantomGame.Randy.NextFloat() + PhantomGame.Randy.NextFloat()) * 10;
                eyes[i].Y = (float)Math.Sin(r) * (PhantomGame.Randy.NextFloat() + PhantomGame.Randy.NextFloat()) * 10;
                r += MathHelper.TwoPi / details.Length + (PhantomGame.Randy.NextFloat() - PhantomGame.Randy.NextFloat()) * 0.3f;
            }
        }

        public override void OnAdd(Component parent)
        {
            base.OnAdd(parent);
            shape = parent.GetComponentByType<Circle>();
            if (shape == null)
                throw new Exception("CreepRenderer expects its parent to have a Circle component.");
        }

        public override void Update(float elapsed)
        {
            base.Update(elapsed);
            float d = elapsed*3.5f;
            cycle += d;
            cycle %= MathHelper.TwoPi;
            if (cycle > MathHelper.Pi*0.5f && cycle - d <= MathHelper.Pi*0.5f)
            {
                GetAncestor<MainGameState>().Tracks.CreateTrack(this.Entity.Position - new Vector2(0, 12), Sprite, 33, Color.Brown, 0.3f);
            }

            if (cycle > MathHelper.Pi * 1.0f && cycle - d <= MathHelper.Pi * 1.0f)
            {
                GetAncestor<MainGameState>().Tracks.CreateTrack(this.Entity.Position - new Vector2(0, 12), Sprite, 34, Color.Brown, 0.3f);
            }

            blink -= elapsed;
            if (blink < 0)
                blink = 2 + PhantomGame.Randy.NextFloat();
        }

        public override void Render(Phantom.Graphics.RenderInfo info)
        {
            base.Render(info);
            if (info.Pass == MainGameState.PassObjects)
            {
                Vector2 pos = this.Entity.Position;
                pos.Y += (float)Math.Cos(cycle+MathHelper.PiOver2) * 12;
                Sprite.RenderFrame(info, 33, pos);
                pos = this.Entity.Position;
                pos.Y += (float)Math.Cos(cycle + MathHelper.Pi) * 12;
                Sprite.RenderFrame(info, 34, pos);

                pos = this.Entity.Position;
                pos.Y += (float)Math.Cos(cycle) * 4;
                Sprite.RenderFrame(info, 32, pos);
                pos.Y += (float)Math.Cos(cycle) * 2;
                for (int i = 0; i < details.Length; i++)
                {
                    Sprite.RenderFrame(info, 35, pos+details[i].Flatten(), 0, details[i].Z);
                }
                int frame = 36;
                if (blink < 0.3)
                    frame = 37;
                for (int i = 0; i < eyes.Length; i++)
                {
                    Sprite.RenderFrame(info, frame, pos + eyes[i] + new Vector2(0, (float)Math.Cos(cycle+(i+1)*0.4f) * 4));
                }
            }
        }
    }
}
