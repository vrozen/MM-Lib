﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom;
using ConverterDefense.MMGlueCode;

/*
namespace ConverterDefense.Creeps
{
    class WaveManager : Component
    {
        private float timer;
        private EntityLayer entities;

        public WaveManager()
        {
            timer = 0.1f;
        }

        public override void OnAdd(Component parent)
        {
            base.OnAdd(parent);
            entities = parent.GetComponentByType<EntityLayer>();
            if (entities == null)
                throw new Exception("WaveManager expects its parent to have a EntityLayer component.");
        }

        public override void Update(float elapsed)
        {
            base.Update(elapsed);
            timer -= elapsed;
            if (timer < 0)
            {
                timer = 1;
                //MainGameState.diagram.HandleSignal("SpawnCreep");
            }
        }
    }
}
*/