﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom;
using Phantom.Misc;

namespace ConverterDefense.Creeps
{
    class CreepMover : Mover
    {
        private float acceleration;
        public CreepMover(float acceleration, float damping)
            : base(new Vector2(0, acceleration), damping, 0, 1)
        {
            this.acceleration = acceleration;
        }

        public override void OnAdd(Component parent)
        {
            base.OnAdd(parent);
            Entity.Position = new Vector2(((PhantomGame.Randy.NextFloat() + PhantomGame.Randy.NextFloat()) * 0.5f + 0.00f) * PhantomGame.Game.Resolution.Width, -30 * (PhantomGame.Randy.NextFloat() + PhantomGame.Randy.NextFloat() + 1));
            Entity.Collidable = false;
            Entity.InitiateCollision = false;
        }

        public override void Integrate(float elapsed)
        {
            base.Integrate(elapsed);
            Velocity.Y += elapsed * acceleration;
        }
    }
}
