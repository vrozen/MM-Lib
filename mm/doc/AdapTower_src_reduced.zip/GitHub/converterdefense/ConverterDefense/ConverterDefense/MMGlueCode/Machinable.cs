﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Phantom.Core;
using LibMM;

namespace ConverterDefense.MMGlueCode
{
    /**
     * When an object is Machinable it has a Micro-Machinations instance
     * associated with it, and it can react to Micro-Machinations messages.
     */
    public interface Machinable
    {
        /**
         * Retrieves the MM instance.
         */
        uint mm_getInstance();

        /**
         * Stores the MM instance.
         */
        void mm_setInstance(uint instance);


        /**
         * Retrieves the MM definition.
         */
        uint mm_getDefinition();

        /**
         * Stores the MM definition.
         */
        void mm_setDefinition(uint definition);

        /**
         * Notifies the Machinable object of MM changes.
         * @msg MM message
         * @nodeName 
         * @context self supplied context (may be null)
         * @value new value
         */
        void mm_update(LibMM.MESSAGE msg, uint instOrDef, uint element, int value);

    }
}
