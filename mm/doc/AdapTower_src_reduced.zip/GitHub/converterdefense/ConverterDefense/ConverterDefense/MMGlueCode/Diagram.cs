﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LibMM;
using System.Runtime.InteropServices;
using Phantom.Core;
using Phantom.Utils;
using System.Diagnostics;
using Phantom;
using Phantom.Utils.Performance;

namespace ConverterDefense.MMGlueCode
{
    //public class MMSignal
    //{
    //    public string Signal;     //signal text
    //    public Entity[] Subjects; //entities asssociated to a signal

    //    public MMSignal(string signal, Entity[] subjects)
    //    {
    //        this.Signal = signal;
    //        this.Subjects = subjects;
    //    }
    //}

    ////not needed?
    //public class MMIdentifier
    //{
    //    public ulong Element;  //node
    //    public ulong Instance; //instance

    //    public MMIdentifier(ulong element, ulong instance)
    //    {
    //        this.Element = element;
    //        this.Instance = instance;
    //    }

    //    public MMIdentifier()
    //        : this(0, 0) { }
    //}


    ///**
    // * A 'static' binding binds a Micro-Machinations name
    // * to a game blueprint from which entitities are created.
    // */
    //public class MMBinding
    //{
    //    public string Label; //Micro-Machinations node name
    //    public int Delta;    //amount plus or minus?
    //    public int State;    //??
        

    //    public MMIdentifier Identifier; //not needed?
        
    //    public PCNComponent Blueprint;  //game component

    //    public MMBinding(string label, string blueprint)
    //    {
    //        this.Label = label;
    //        this.Delta = 0;
    //        this.State = 0;
    //        Identifier = new MMIdentifier();
    //        if (blueprint != null)
    //        {
    //            this.Blueprint = new PCNComponent(blueprint);
    //        }
    //    }
    //}

    public class Diagram
    {
        private Machine machine; /**> Micro-Machinations wrapper*/

        private EntityLayer entityLayer;

        //private Dictionary<ulong,       /**> MM element */
        //                   MMBinding>   /**> 'static' binding */
        //                   bindings;    /**> mapping from MM element to 'static' bindings */

        //private MMSignal currentSignal;
        //private List<Entity> addedEntities;

        //protected Dictionary<uint,  //definition
        //             PCNComponent> //blueprint
        //             blueprints;


        private uint globalInstance;
        private uint globalDefinition;

        //added by rozen
        public List<string> modifications; /**> List of modifications */
        public int curModification;        /**> Current modification */

        //used by MM to call back Machinable objects
        private Dictionary<uint,       /**> MM instance */
                           Machinable> /**> Machinable entity or component */
                           instances;  /**> mapping from MM instances to 'dynamic' game instances */


        private Dictionary<uint,
                           Machinable>
                           definitions;

        private List<Machinable> globals;

        //we need a kind of queue for defintions
        //requests (that can be cancelled) for creating a Tower, Base and even essence (at a certain location (context))
        //but this may then only happen when an instance is created of the right type or if a
        //after this the request can be sent back as a success

        public Diagram(EntityLayer entities)
        {
            //store reference to entity layer
            entityLayer = entities;

            //instantiate a new machine
            machine = new Machine();

            //constant information
            globalInstance = machine.getGlobalInstance();
            globalDefinition = machine.getGlobalDefinition();
            
            //machine.addInstanceObserver(globalInstance, 0, Callback);

            //instance bindings
            instances = new Dictionary<uint, Machinable>();

            //definition bindings
            definitions = new Dictionary<uint, Machinable>();

            globals = new List<Machinable>();

            //modifications to evaluate
            modifications = new List<string>();


            //blueprints = new Dictionary<uint, PCNComponent>();

            //bindings will contain static bindings
            //bindings = new Dictionary<ulong, MMBinding>();

            //temporary info used when processing signals
            //currentSignal = null;
            //addedEntities = new List<Entity>();
            machine.addInstanceObserver(globalInstance, 0, instanceCallback);

        }

        /**
         * Adds a modification file to the list. 
         */
        public void addModel(string file)
        {
            modifications.Add(file);
        }

        public void evalModel(string file)
        {
            machine.evalFile(file);
        }

        /**
         * Evaluates the next modification. 
         */
        public void evalNext()
        {
            if (curModification < modifications.Count())
            {
                string file = modifications.ElementAt(curModification);
                machine.evalFile(file);
                curModification++;
            }
        }

        /**
         * Returns true if there is a next model to evaluate, false otherwise.
         */
        public bool hasNextModification()
        {
            return curModification < modifications.Count();
        }

        public uint getGlobalInstance()
        {
            return globalInstance;
        }

        public void step()
        {
            machine.step();
        }


        private void instanceCallback(uint caller,   //unused
                                      uint message,  //converted and passed --> could be redirected to speficalized overloadable method
                                      uint instance, //hidden
                                      uint element,  //hidden --> name
                                      int value)    //passed
        {
            MESSAGE msg = (MESSAGE)message;

            String textMessage = msg.ToString() + "  " + machine.getInstanceName(instance) + " " + machine.getName(element) + " " + value;

            Trace.WriteLine(textMessage);
            Console.WriteLine(textMessage);

            if (instance == globalInstance)
            {
                foreach(Machinable m in globals)
                {
                    m.mm_update(msg, instance, element, value);
                }
            }
            else if (instances.ContainsKey(instance))
            {
                Machinable m = instances[instance];
                m.mm_update(msg, instance, element, value);
            }
        }

        private void definitionCallback(uint caller,     //unused
                                        uint message,    //converted and passed --> could be redirected to speficalized overloadable method
                                        uint definition, //hidden
                                        uint element,    //hidden --> name
                                        int value)      //passed
        {
            MESSAGE msg = (MESSAGE)message;
            Console.Write(msg.ToString());
            Console.Write(" " + machine.getName(definition));
            Console.Write(" " + machine.getName(element));
            Console.WriteLine(" " + value);

            if (definitions.ContainsKey(definition))
            {
                Machinable m = definitions[definition];
                String name = machine.getName(element);

                m.mm_update(msg, definition, element, value);
            }
        }

        /*
        private void Callback(uint caller,
                              uint message,
                              uint instance,
                              uint element,
                              uint value)
        {
            MESSAGE msg = (MESSAGE) message;
            //Trace.WriteLine("Got a callback! " + mes.ToString() + " " + instance + " " + machine.getName(element) + " " + value);
            
            Console.Write(msg.ToString());
            Console.Write(" " + machine.getInstanceName(instance));
            Console.Write(" " + machine.getName(element));
            Console.WriteLine(" " + value);

            MMBinding binding = null;

            if (bindings.ContainsKey((ulong)element))
            {
                binding = bindings[(ulong)element];
            }
            else
            {
                Console.Out.WriteLine("Missing binding!");
            }

            if (binding == null)
                return;

            switch (msg)
            {
                case MESSAGE.MSG_HAS_VALUE:
                    //lookup instance and node
                    //if callback found
                    //  notify object and call method to 'set' game data

                case MESSAGE.MSG_ADD_VALUE:
                    binding.Delta = (int)value;
                    ApplyChanges(binding);
                    break;
                case MESSAGE.MSG_SUB_VALUE:
                    binding.Delta = -(int)value;
                    ApplyChanges(binding);
                    break;
                case MESSAGE.MSG_NEW_INST:
                    //create a new entity 
                    Entity e = EntityFactory.AssembleEntity(binding.Blueprint, binding.Label);
                    entityLayer.AddComponent(e);
                    addedEntities.Add(e);
                    break;
                case MESSAGE.MSG_DEL_INST:
                    //find the entity this instance belongs to and destroy it
                    break;
                default:
                    return;
            }
            
        }*/

        /**
         * Bind a Machinable object to a type by providing its (global) name.
         * It will receive messages about the specified definition.
         * @param m Machinable object
         * @param name global definition name
         */
        public void bindDefinition(Machinable m, String name)
        {
            uint definition = machine.getElement(globalDefinition, name);
            if (definition != 0)
            {
                m.mm_setDefinition(definition);

                if (definitions.ContainsKey(definition) == false)
                {
                    definitions.Add(definition, m);
                    machine.addDefinitionObserver(definition, 0, definitionCallback);
                }
            }
        }

        public void bindInstance(Machinable m, uint instance)
        {
            m.mm_setInstance(instance);
            uint definition = machine.getDefinition(instance);
            m.mm_setDefinition(definition);

            if (instances.ContainsKey(instance) == false)
            {
                instances.Add(instance, m);
                machine.addInstanceObserver(instance, 0, instanceCallback);
            }
        }

        public void bindGlobalInstance(Machinable m)
        {
            m.mm_setInstance(globalInstance);
            globals.Add(m);
        }


        //existing "old" definition of binding
        //public void BindElement(MMBinding element)
        //{
        //    element.Identifier.Instance = globalInstance;
        //    element.Identifier.Element = machine.getElement(globalDefinition, element.Label);
        //    if (element.Identifier.Element>0)
        //        bindings[element.Identifier.Element] = element;
        //}

        /**
         * activate a node inside an instance
         * @param m Machinable object
         * @param nodeName the name of the node to activate inside the instance of m 
         */

        public void activate(String nodeName)
        {
            if(globalInstance != 0 && globalDefinition != 0)
            {
                uint node = machine.getElement(globalDefinition, nodeName);
                if (node != 0)
                {
                    machine.activate(node, globalInstance);
                }
            }
        }

        public void activate(Machinable m, String nodeName)
        {
            uint instance = m.mm_getInstance();
            if (instance != 0)
            {
                uint definition = machine.getDefinition(instance);
                if (definition != 0)
                {
                    String name = getName(definition);
                    uint node = machine.getElement(definition, nodeName);

                    if (node != 0)
                    {
                        machine.activate(node, instance);
                    }
                }
            }            
        }

        public String getModel()
        {
            return machine.getModel();
        }

        public String getName(uint element)
        {
            return machine.getName(element);
        }

        public bool isInteractive(Machinable m, String nodeName)
        {
            uint definition = m.mm_getDefinition();

            uint node = machine.getElement(definition, nodeName);

            return machine.isInteractive(node);
        }

        /**
         * HandleSignal receives signals from the Physics and UI,
         * processes all related Micro-Machinations until they are 'done'
         * and returns any entities that have been added as a result.
         * @param scope entitiy this singal comes from (why unused?)
         * @param signal name of the MM node to activate in the global instance
         * @param stepCount number of steps to evaluate
         * @param entitities entitites that this signal applies to (?)
         */
    //    public Entity[] HandleSignal(Entity scope, string signal, int stepCount, params Entity[] entities)
    //    {

    //        //blocking wait (...)
    //        while (currentSignal != null)
    //        {
    //            //Console.WriteLine("Waiting on " + signal);
    //        }

    //        Trace.WriteLine("Handling signal "+signal+"...");
    //        //Profiler.BeginProfiling("HandleSignal");
    //        addedEntities.Clear();

    //        currentSignal = new MMSignal(signal, entities);
    //        //TODO if there is a scope, then check if it has its own instance and look for the values inside that instance)
    //        uint element = machine.getElement(globalDefinition, signal);

    //        if (element > 0)
    //        {
    //            machine.activate(element, globalInstance);

    //            for (int i = 0; i < stepCount; i++)
    //            {
    //                machine.step();
    //            }
    //        }


    //        currentSignal = null;
    //        //Profiler.EndProfiling("HandleSignal");
    //        Trace.WriteLine("Handle signal " + signal+ " done.");
    //        return addedEntities.ToArray();
    //    }


    //    public Entity[] HandleSignal(string signal, int stepCount, params Entity[] entities)
    //    {
    //        return HandleSignal(null, signal, stepCount, entities);
    //    }

    //    private void ApplyChanges(MMBinding binding)
    //    {
    //        if (binding.Delta>0)
    //        {
    //            AddEntities(binding);
    //        }
    //        else if (binding.Delta < 0)
    //        {
    //            //Remove Entities
    //            if (currentSignal != null)
    //                RemoveEntities(currentSignal.Subjects, binding);
    //            else
    //                RemoveEntities(new Entity[0], binding);

    //        }

    //        binding.State += binding.Delta;
    //        binding.Delta = 0;
    //    }

        
    //    private void RemoveEntities(Entity[] entities, MMBinding binding)
    //    {
    //        //Check for same type of entities in the entity list passed to the function
    //        foreach (Entity e in entities)
    //        {
    //            if (!e.Destroyed && e.Properties.GetString(EntityFactory.PROPERTY_NAME_BLUEPRINT, "") == binding.Label)
    //            {
    //                e.Destroyed = true;
    //                binding.Delta--;
    //                if (binding.Delta <= 0)
    //                    return; //and we're done
    //            }
    //        }

    //        //Do I still need to remove entities? Remove them from the list
    //        for (int i = 0; i < entityLayer.Components.Count; i++)
    //        {
    //            Entity e = entityLayer.Components[i] as Entity;
    //            if (e != null && !e.Destroyed && e.Properties.GetString(EntityFactory.PROPERTY_NAME_BLUEPRINT, "") == binding.Label)
    //            {
    //                e.Destroyed = true;
    //                binding.Delta--;
    //                if (binding.Delta <= 0)
    //                    return; //and we're done
    //            }
    //        }
    //    }

    //    private void AddEntities(MMBinding binding)
    //    {
    //        for (int i = 0; i < binding.Delta; i++)
    //        {
    //            Entity e = EntityFactory.AssembleEntity(binding.Blueprint, binding.Label);
    //            entityLayer.AddComponent(e);
    //            addedEntities.Add(e);
    //        }
    //    }

    }
}
