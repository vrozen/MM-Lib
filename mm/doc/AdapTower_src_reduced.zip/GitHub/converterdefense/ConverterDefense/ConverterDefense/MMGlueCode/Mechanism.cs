﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Phantom.Core;

using Phantom.Utils;

namespace ConverterDefense.MMGlueCode
{
    public abstract class Mechanism : EntityComponent, Machinable
    {
        private uint instance;      // 1-to-1 binding to MM instance
        private uint definition;    // 1-to-1 binding to MM definition
        //protected Diagram diagram;  // diagram this machinable belongs to

        public Mechanism()
        {
            instance = 0;
        }

        public void mm_setInstance(uint instance)
        {
            this.instance = instance;
        }

        public uint mm_getInstance()
        {
            return instance;
        }

        public void mm_setDefinition(uint definition)
        {
            this.definition = definition;
        }

        public uint mm_getDefinition()
        {
            return definition;
        }

        public void mm_update(LibMM.MESSAGE msg, uint instOrDef, uint element, int value)
        {
            //String name = diagram.getName(element);

            String name = null;

            switch (msg)
            {
                case LibMM.MESSAGE.MSG_NEW_INST:
                    name = MainGameState.diagram.getName((uint)value);
                    onNewInstance(name, element);
                    break;
                case LibMM.MESSAGE.MSG_DEL_INST:
                    name = MainGameState.diagram.getName((uint)value);
                    onDeleteInstance(name, element);
                    break;
                case LibMM.MESSAGE.MSG_HAS_VALUE:
                    name = MainGameState.diagram.getName(element);
                    onUpdateValue(name, value);
                    break;
                case LibMM.MESSAGE.MSG_ADD_VALUE:
                    name = MainGameState.diagram.getName(element);
                    onAddValue(name, value);
                    break;
                case LibMM.MESSAGE.MSG_SUB_VALUE:
                    name = MainGameState.diagram.getName(element);
                    onSubValue(name, value);
                    break;
                case LibMM.MESSAGE.MSG_ACTIVATE:
                    name = MainGameState.diagram.getName(element);
                    onActivateNode(name);
                    break;
                case LibMM.MESSAGE.MSG_DISABLE:
                    name = MainGameState.diagram.getName(element);
                    onDisableNode(name);
                    break;
                case LibMM.MESSAGE.MSG_ENABLE:
                    name = MainGameState.diagram.getName(element);
                    onEnableNode(name);
                    break;
                case LibMM.MESSAGE.MSG_NEW_DRAIN:
                case LibMM.MESSAGE.MSG_NEW_SOURCE:
                case LibMM.MESSAGE.MSG_NEW_POOL:
                case LibMM.MESSAGE.MSG_NEW_CONVERTER:
                case LibMM.MESSAGE.MSG_NEW_GATE:
                    name = MainGameState.diagram.getName(element);
                    onNewNode(name);
                    break;
                case LibMM.MESSAGE.MSG_DEL_DRAIN:
                case LibMM.MESSAGE.MSG_DEL_SOURCE:
                case LibMM.MESSAGE.MSG_DEL_POOL:
                case LibMM.MESSAGE.MSG_DEL_CONVERTER:
                case LibMM.MESSAGE.MSG_DEL_GATE:
                    name = MainGameState.diagram.getName(element);
                    onDeleteNode(name);
                    break;
                case LibMM.MESSAGE.MSG_UPD_DRAIN:
                case LibMM.MESSAGE.MSG_UPD_SOURCE:
                case LibMM.MESSAGE.MSG_UPD_POOL:
                case LibMM.MESSAGE.MSG_UPD_CONVERTER:
                case LibMM.MESSAGE.MSG_UPD_GATE:
                    name = MainGameState.diagram.getName(element);
                    onUpdateNode(name);
                    break;
                case LibMM.MESSAGE.MSG_FAIL:
                    name = MainGameState.diagram.getName(element);
                    onFailNode(name);
                    break;
                case LibMM.MESSAGE.MSG_PREVENT:
                    name = MainGameState.diagram.getName(element);
                    onPreventEdge(name);
                    break;
                case LibMM.MESSAGE.MSG_TRIGGER:
                    name = MainGameState.diagram.getName(element);
                    onTriggerEdge(name);
                    break;
                case LibMM.MESSAGE.MSG_VIOLATE:
                    name = MainGameState.diagram.getName(element);
                    onViolateAssertion(name);
                    break;
                default:
                    break; 
                   //message not understood
            }

        }

        /**
         * when bound to an instance
         */
        protected virtual void onAddValue(String nodeName, int value)
        {
        }

        protected virtual void onSubValue(String nodeName, int value)
        {
        }

        protected virtual void onUpdateValue(String nodeName, int value)
        {
        }

        protected virtual void onNewInstance(String declName, /*Entity e*/ uint instance)
        {
        }

        protected virtual void onDeleteInstance(String declName, /*Entity e*/ uint instance)
        {
        }

        protected virtual void onEnableNode(String nodeName)
        {
        }

        protected virtual void onDisableNode(String nodeName)
        {
        }

        protected virtual void onActivateNode(String nodeName)
        {
        }

        protected virtual void onFailNode(String nodeName)
        {
        }

        protected virtual void onPreventEdge(String edgeName)
        {
        }


        protected virtual void onTriggerEdge(String edgeName)
        {
        }

        protected virtual void onViolateAssertion(String nodeName)
        {
        }


        /**
         * when bound to an definition
         */
        protected virtual void onNewNode(String nodeName)
        {
        }

        protected virtual void onDeleteNode(String nodeName)
        {
        }

        protected virtual void onUpdateNode(String nodeName)
        {
        }

    }
}
