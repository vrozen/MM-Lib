﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using System.Diagnostics;
using Phantom.Utils;

//NOTE: no longer in use
/*
namespace ConverterDefense.MMGlueCode
{
    public class FauxDiagram
    {
        private EntityLayer entityLayer;
        private Dictionary<string, MMBinding> bindings;
        private MMSignal currentSignal;
        private List<Entity> addedEntities;
        public MainGameState Game;

        private int gold;
        private int progress;

        public FauxDiagram(EntityLayer entities)
        {
            entityLayer = entities;
            bindings = new Dictionary<string, MMBinding>();
            currentSignal = null;
            addedEntities = new List<Entity>();

            gold = 50 + 60;
        }

        public void BindElement(MMBinding element)
        {
            bindings[element.Label] = element;
        }

        public Entity[] HandleSignal(Entity scope, string signal, int stepCount, params Entity[] entities)
        {

            while (currentSignal != null)
            { }
            Trace.WriteLine("Handling signal " + signal + "...");
            //Profiler.BeginProfiling("HandleSignal");
            addedEntities.Clear();

            currentSignal = new MMSignal(signal, entities);
            Entity entity;
            switch (signal)
            {
                case "SpawnCreep":
                    for (int i = 0; i < (progress / 3) + 1; i++)
                    {
                        entity = EntityFactory.AssembleEntity(bindings["Creeps"].Blueprint, "Creeps");
                        addedEntities.Add(entity);
                        entityLayer.AddComponent(entity);
                    }
                    break;
                case "BuildTower":
                    if (gold >= 10)
                    {
                        entity = EntityFactory.AssembleEntity(bindings["Towers"].Blueprint, "Towers");
                        addedEntities.Add(entity);
                        entityLayer.AddComponent(entity);
                        gold -= 10;
                    }
                    break;
                case "BuildBase":
                    if (gold >= 20)
                    {
                        entity = EntityFactory.AssembleEntity(bindings["Bases"].Blueprint, "Base");
                        addedEntities.Add(entity);
                        entityLayer.AddComponent(entity);
                        gold -= 20;
                        if (Game != null)
                            Game.ChangeBases(1);
                        progress++;
                    }
                    break;
                case "KillCreep":
                    for (int i = 0; i < entities.Length; i++)
                        entities[i].Destroyed = true;
                    for (int i = 0; i < 5; i++)
                    {
                        entity = EntityFactory.AssembleEntity(bindings["Essence"].Blueprint, "Essence");
                        addedEntities.Add(entity);
                        entityLayer.AddComponent(entity);
                    }
                    break;
                case "CollectGold":
                    gold++;
                    for (int i = 0; i < entities.Length; i++)
                        entities[i].Destroyed = true;
                    break;
                case "RemoveEssence":
                case "RemoveCreep":
                case "HitTower":
                    for (int i = 0; i < entities.Length; i++)
                        entities[i].Destroyed = true;
                    break;
                case "HitBase":
                    for (int i = 0; i < entities.Length; i++)
                        entities[i].Destroyed = true;
                    if (Game != null)
                        Game.ChangeBases(-1);
                    break;

            }
            
            currentSignal = null;
            //Profiler.EndProfiling("HandleSignal");
            Trace.WriteLine("Handle signal " + signal + " done.");
            return addedEntities.ToArray();
        }


        public Entity[] HandleSignal(string signal, int stepCount, params Entity[] entities)
        {
            return HandleSignal(null, signal, stepCount, entities);
        }


        internal int GetGold()
        {
            return gold;
        }
    }
}
*/