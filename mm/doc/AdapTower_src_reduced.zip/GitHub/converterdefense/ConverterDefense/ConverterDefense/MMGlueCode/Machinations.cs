﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Shapes;
using ConverterDefense.Creeps;
using ConverterDefense.Resources;
using ConverterDefense.Towers;
using System.Diagnostics;
//using PhantomGrammar.GrammarCore;
using System.Reflection;
using Phantom.Misc;
using Phantom.Utils;

namespace ConverterDefense.MMGlueCode
{
    /*public enum MachinationsElementType { Pool, Collection, Condition }

    public class MachinationsElement
    {
        public MachinationsElementType Type;
        public int State;
        public int Delta;
        public string Label;
        public bool Active;
        public PCNComponent Blueprint;

        public MachinationsElement(string label, MachinationsElementType type, int initialState, bool active, string blueprint)
        {
            this.Label = label;
            this.Type = type;
            this.State = 0;
            this.Delta = initialState;
            this.Active = active;
            if (blueprint != null)
            {
                this.Blueprint = new PCNComponent(blueprint);
                Trace.WriteLine("Parsed blueprint: " + blueprint.ToString());
            }
        }
    }

    /// <summary>
    /// Fake Machinations class to simulate a machinations binding.
    /// </summary>
    public class Machinations
    {
        //reference to the entity layer
        private EntityLayer entityLayer;

        //fake diagram
        private Dictionary<string, MachinationsElement> elements;

        public Machinations(EntityLayer entityLayer)
        {
            elements = new Dictionary<string, MachinationsElement>();
            this.entityLayer = entityLayer;
        }

        public void AddElement(MachinationsElement element)
        {
            elements[element.Label] = element;
        }

        public Entity[] StartDiagram()
        {
            List<Entity> result = new List<Entity>();
            foreach (KeyValuePair<string, MachinationsElement> element in elements)
            {
                element.Value.State += element.Value.Delta;
                if (element.Value.State > 0 && element.Value.Blueprint != null)
                    AddEntities(result, element.Key, element.Value.State, element.Value.Blueprint);
            }
            return result.ToArray();
        }

        public string Report()
        {
            string r = "";
            foreach (KeyValuePair<string, MachinationsElement> element in elements)
            {
                switch (element.Value.Type)
                {
                    case MachinationsElementType.Pool:
                    case MachinationsElementType.Collection:
                        if (element.Value.Active) 
                            r += element.Key + "=" + element.Value.State + " ";
                        else
                            r += "("+element.Key + ") ";
                        break;
                    case MachinationsElementType.Condition:
                        if (element.Value.Active) 
                            r += element.Key.ToUpper() + " ";
                        else
                            r += "("+element.Key + ") ";
                        break;
                }
            }
            return r;
        }

        public Entity[] HandleSignal(string signal, params Entity[] entities)
        {
            ClearDelta();
            switch (signal)
            {
                case "SpawnCreep":
                    elements["creeps"].Delta = 1;
                    break;
                case "CreepInBase":
                    elements["creeps"].Delta = -1;
                    elements["bases"].Delta = -1;
                    break;
                case "RemoveCreep":
                    elements["creeps"].Delta = -1;
                    break;
                case "KillCreep":
                    if (elements["creeps"].State >= 1) 
                    {
                        elements["creeps"].Delta = -1;
                        elements["fallingGold"].Delta = 5;
                    }
                    break;
                case "BuildTower1":
                    if (elements["gold"].State >= 20)
                    {
                        elements["towers1"].Delta = 1;
                        elements["gold"].Delta = -20;
                    }
                    break;
                case "BuildTower2":
                    if (elements["gold"].State >= 20)
                    {
                        elements["towers2"].Delta = 1;
                        elements["gold"].Delta = -20;
                    }
                    break;
                case "BuildTower3":
                    if (elements["gold"].State >= 20)
                    {
                        elements["towers3"].Delta = 1;
                        elements["gold"].Delta = -20;
                    }
                    break;
                case "BuildBase":
                    if (elements["gold"].State >= 20)
                    {
                        elements["bases"].Delta = 1;
                        elements["gold"].Delta = -20;
                    }
                    break;
                case "CollectGold":
                    elements["fallingGold"].Delta = -1;
                    elements["gold"].Delta = 1;
                    break;
                case "RemoveGold":
                    elements["fallingGold"].Delta = -1;
                    break;
            }
            return ApplyChanges(entities);
        }

        public int GetState(string element)
        {
            if (elements.ContainsKey(element))
                return elements[element].State;
            else
                return 0;
        }

        public bool GetActivation(string element)
        {
            if (elements.ContainsKey(element))
                return elements[element].Active;
            else
                return false;
        }


        private Entity[] ApplyChanges(Entity[] entities)
        {
            List<Entity> result = new List<Entity>();
            foreach (KeyValuePair<string, MachinationsElement> element in elements)
            {
                element.Value.State += element.Value.Delta;
                if (element.Value.Delta < 0 && element.Value.Blueprint != null)
                    RemoveEntities(entities, element.Key, -element.Value.Delta);
                if (element.Value.Delta > 0 && element.Value.Blueprint != null)
                    AddEntities(result, element.Key, element.Value.Delta, element.Value.Blueprint);
            }
            return result.ToArray();
        }

        private void ClearDelta()
        {
            foreach (KeyValuePair<string, MachinationsElement> element in elements)
                element.Value.Delta = 0;
        }

        private void RemoveEntities(Entity[] entities, string key, int count)
        {
            //Check for same type of entities in the entity list passed to the function
            foreach (Entity e in entities)
            {
                if (!e.Destroyed && e.Properties.GetString(EntityFactory.PROPERTY_NAME_BLUEPRINT, "") == key)
                {
                    e.Destroyed = true;
                    count--;
                    if (count <= 0)
                        return; //and we're done
                }
            }

            //Do I still need to remove entities? Remove them from the list
            for (int i = 0; i < entityLayer.Components.Count; i++)
            {
                Entity e = entityLayer.Components[i] as Entity;
                if (e != null && !e.Destroyed && e.Properties.GetString(EntityFactory.PROPERTY_NAME_BLUEPRINT, "") == key)
                {
                    e.Destroyed = true;
                    count--;
                    if (count <= 0)
                        return; //and we're done
                }
            }

        }

        private void AddEntities(List<Entity> entities, string key, int count, PCNComponent blueprint)
        {
            for (int i = 0; i < count; i++)
            {
                Entity e = EntityFactory.AssembleEntity(blueprint, key); 
                entities.Add(e);
                entityLayer.AddComponent(e);
            }
        }

        
    

    }*/
}
