﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Microsoft.Xna.Framework;
using Phantom.Misc;

using Phantom.Utils;
using Phantom;
using ConverterDefense.Towers;
using ConverterDefense.MMGlueCode;

namespace ConverterDefense.UI
{
    public class TowerUpgrade : Mechanism
    {
        private PCNComponent towerBluePrint = new PCNComponent("Tower");

        private EntityLayer entities;

        private List<String> interactiveNodes;

        private static String[] builtinNodes = { "killCreep", "hitByCreep", "tick" };

        public TowerUpgrade(EntityLayer entities)
        {
            MainGameState.diagram.bindDefinition(this, "Tower");
            this.entities = entities;
            interactiveNodes = new List<String>();
        }

        public Tower createTower(Vector2 position, uint instance)
        {
            Tower tower = (Tower) EntityFactory.AssembleEntity(towerBluePrint, "Tower");
            tower.Position = position;
            Mechanism mechanism = tower.GetComponentByType<Mechanism>();
            MainGameState.diagram.bindInstance(mechanism, instance);

            foreach(String nodeName in interactiveNodes)
            {
                UpgradeButton button = new UpgradeButton(mechanism, nodeName);
                UpgradeControl ug = tower.GetComponentByType<UpgradeControl>();
                ug.AddComponent(button);
            }

            return tower;
        }

        protected override void onNewNode(string nodeName)
        {
            if (builtinNodes.Contains(nodeName) == false)
            {
                if (interactiveNodes.Contains(nodeName) == false)
                {
                    if (MainGameState.diagram.isInteractive(this, nodeName) == true)
                    {
                        interactiveNodes.Add(nodeName);
                        foreach (Tower tower in entities.GetAllComponentsByType<Tower>())
                        {
                            Mechanism m = tower.GetComponentByType<Mechanism>();
                            UpgradeButton button = new UpgradeButton(m, nodeName);
                            UpgradeControl ug = tower.GetComponentByType<UpgradeControl>();
                            ug.AddComponent(button);
                        }
                    }
                }
            }
        }

        protected override void onDeleteNode(string nodeName)
        {
            if (interactiveNodes.Contains(nodeName))
            {
                interactiveNodes.Remove(nodeName);
            }
            //TODO: remove component from existing towers
            //TODO: make this a generic class
        }
    }
}
