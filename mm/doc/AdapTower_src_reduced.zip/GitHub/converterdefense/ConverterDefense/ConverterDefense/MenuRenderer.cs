﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Phantom.Graphics;
using Phantom;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Phantom.Misc;
using ConverterDefense.Resources;
using ConverterDefense.UI;

namespace ConverterDefense
{
    public class MenuRenderer : RenderLayer
    {
        private float timer;
        private string[] text = { "Instructions:", 
                                    "left-click to buy tower,", 
                                    "right-click to buy base,", 
                                    "build as many bases as you can!", 
                                    "Click to start game" };
        public MenuRenderer()
            : base(new Renderer(2))
        {
            AddComponent(new Image(new Sprite(PhantomGame.Game.Content.Load<Texture2D>("sprites/at_background"))));
            AddComponent(new Image(new Sprite(PhantomGame.Game.Content.Load<Texture2D>("sprites/at_title")), new Vector2(PhantomGame.Game.Width*0.5f, PhantomGame.Game.Width*0.25f)));
        }

        public override void Render(RenderInfo info)
        {
            base.Render(info);
            if (info != null && info.Pass == 1)
            {
                timer += info.Elapsed;
                Vector2 pos = new Vector2(PhantomGame.Game.Width * 0.5f, PhantomGame.Game.Width * 0.4f);
                for (int i = 0; i < text.Length; i++)
                {
                    Vector2 size = AdapTower.HudFont.MeasureString(text[i]);
                    Color c = AdapTower.ShadowColor;
                    if (i == text.Length - 1)
                    {
                        pos.Y += AdapTower.HudFont.LineSpacing * 1.0f;
                        if (timer % 0.5f > 0.3f)
                            continue;
                    }
                    info.Batch.DrawString(AdapTower.HudFont, text[i], pos, c, 0, size * 0.5f, 1, SpriteEffects.None, 0);
                    pos.Y += AdapTower.HudFont.LineSpacing*1.0f;
                }

                //Resource.RenderCoin(info, new Vector2(100, 100), timer, (timer * 0.3f) % 2, 8);

                ScoreHud.RenderText(info, "Last Score", new Vector2(PhantomGame.Game.Width * 0.1f, 20), 1.0f, AdapTower.ScoreColor, AdapTower.ShadowColor);
                ScoreHud.RenderText(info, MainGameState.LastScore.ToString(), new Vector2(PhantomGame.Game.Width * 0.1f, 50), 1.0f, AdapTower.ScoreColor, AdapTower.ShadowColor);
                ScoreHud.RenderText(info, "High Score", new Vector2(PhantomGame.Game.Width * 0.9f, 20), 1.0f, AdapTower.ScoreColor, AdapTower.ShadowColor);
                ScoreHud.RenderText(info, MainGameState.BestScore.ToString(), new Vector2(PhantomGame.Game.Width * 0.9f, 50), 1.0f, AdapTower.ScoreColor, AdapTower.ShadowColor);

            }

        }
    }
}
