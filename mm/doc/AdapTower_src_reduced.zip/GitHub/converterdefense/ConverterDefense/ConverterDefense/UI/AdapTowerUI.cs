﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.GameUI;
using Phantom.Graphics;
using Microsoft.Xna.Framework;
using Phantom;
using Phantom.Shapes;
using Phantom.Core;
using ConverterDefense.MMGlueCode;
using Microsoft.Xna.Framework.Input;
using ConverterDefense.Towers;
using ConverterDefense.Bases;
using Phantom.Misc;
using Phantom.Utils;
using ConverterDefense.Underwater;

namespace ConverterDefense.UI
{
    public class AdapTowerUI :  Mechanism /*Component, Machinable*/
    {
        //private string tool; 
        private MouseState previous;
        private EntityLayer entities;
        private KeyboardState previousKB;


        //added by rozen
        private PCNComponent creepBlueprint = new PCNComponent("Creep");
        private MainGameState state;
        private Vector2 position;
        private Entity selectedEntity;

        private TowerUpgrade towerFactory;
        private BaseUpgrade baseFactory;

        public AdapTowerUI(MainGameState state, TowerUpgrade towerFactory, BaseUpgrade baseFactory, EntityLayer entities)
        {
            this.state = state;
            this.entities = entities;
            this.towerFactory = towerFactory;
            this.baseFactory = baseFactory;
            this.position = Vector2.Zero;

            MainGameState.diagram.bindGlobalInstance(this);
        }

        public override void OnAdd(Component parent)
        {
            base.OnAdd(parent);
            previous = Mouse.GetState();
            previousKB = Keyboard.GetState();
        }

        public override void Update(float elapsed)
        {
            base.Update(elapsed);
            MouseState current = Mouse.GetState();

            if (current.LeftButton == ButtonState.Pressed && previous.LeftButton != ButtonState.Pressed)
            {
                AddTower(new Vector2(current.X, current.Y), "buyTower", false);
            }
            else if (current.RightButton == ButtonState.Pressed && previous.RightButton != ButtonState.Pressed)
            {
                AddTower(new Vector2(current.X, current.Y), "buyBase", false);
            }

            //1. store the context (position)
            //2. activate the correct converter "buyTower" or "buyBase"
            //3. create a Tower or a Base (using the context and the newly created instance)


            KeyboardState currentKB = Keyboard.GetState();
            if (currentKB.IsKeyDown(Keys.Escape) && !previousKB.IsKeyDown(Keys.Escape))
            {
                state.goUnderWater();
            }

            previous = current;
            previousKB = currentKB;
        }


        public void AddTower(Vector2 position, string node /*buyBase or buyTower*/, bool secondTry)
        {
            //if there is a selected node
            if (selectedEntity != null)
            {
                //Click is handled by the selected entity
                if (selectedEntity.HandleMessage(ATMessages.ClickAt, position).Handled)
                    return;
            }


            float radius = Tower.Radius;
            if (node == "buyBase")
            {
                radius = Base.Radius;
            }


            //check if you can build at the current spot...
            IEnumerable<Entity> entities = this.entities.GetEntitiesInRect(position - new Vector2(radius, radius), position + new Vector2(radius, radius), true);


            if (!secondTry)
            {
                foreach (Entity entity in entities)
                {
                    if ((entity.Flags & ATFlags.Resource) > 0)
                        continue;
                    Circle circle = entity.Shape as Circle;
                    if (circle != null)
                    {
                        Vector2 delta = position - entity.Position;
                        float distance = delta.Length();
                        if (distance < circle.Radius)
                        {
                            SelectEntity(entity);
                            return;
                        }
                    }
                }
            }

            //clicking no where, if something is selected: deselect it
            if (selectedEntity != null)
            {
                SelectEntity(null);
                return;
            }

            //build something
            foreach (Entity entity in entities)
            {
                if ((entity.Flags & ATFlags.Resource) > 0)
                    continue;
                Circle circle = entity.Shape as Circle;
                if (circle != null)
                {
                    Vector2 delta = position - entity.Position;
                    float minDistance = (radius + circle.Radius);
                    float distance = delta.Length();
                    if (distance < minDistance)
                    {
                        if (!secondTry && (entity.Flags & ATFlags.Creep) == 0 && distance>circle.Radius)
                        {
                            delta = delta.Normalized();
                            delta *= minDistance;
                            AddTower(entity.Position + delta, node, true);
                            return;
                        }

                        //cannot build here
                        //TODO Make sound

                        return;
                    }
                }
            }
            

            //Entity[] towers = MainGameState.diagram.HandleSignal(tool, 3);
            //foreach (Entity tower in towers)
            //    tower.Position = position;


            this.position = position;

            //added by rozen
            MainGameState.diagram.activate(this, node);

        }

        private void SelectEntity(Phantom.Core.Entity entity)
        {
            if (selectedEntity != null)
                selectedEntity.HandleMessage(ATMessages.Deselect);
            selectedEntity = entity;
            if (selectedEntity != null)
                selectedEntity.HandleMessage(ATMessages.Select);
        }


        protected override void onUpdateValue(string nodeName, int value)
        {
            switch (nodeName)
            {
                case "gold":
                    state.Gold = value;
                    break;
                case "bases":
                    state.Bases = value;
                    break;
                default:
                    //not used
                    break;
            }
        }

        protected override void onAddValue(string nodeName, int value)
        {
            switch (nodeName)
            {
                case "creeps":
                    for (int i = 0; i < value; i++)
                    {
                        Entity e = EntityFactory.AssembleEntity(creepBlueprint, "Creep");
                        entities.AddComponent(e);
                    }
                    break;
                default:
                    //not used
                    break;
            }
        }

        /*
        protected override void onDisabled(string nodeName)
        {
            switch (nodeName)
            {
                case "buyTower":
                    position = Vector2.Zero;
                    break;
                case "buyBase":
                    position = Vector2.Zero;
                    break;
            }
        }*/

        protected override void onNewInstance(String name, uint instance)
        {
            Entity entity = null;
            switch (name)
            {
                case "Tower":
                    entity = towerFactory.createTower(this.position, instance);
                    entities.AddComponent(entity);
                    break;
                case "Base":
                    entity = baseFactory.createBase(this.position, instance);
                    entities.AddComponent(entity);
                    break;
            }
        }
    }
}
