﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Phantom.Core;
using Phantom.Graphics;
using Microsoft.Xna.Framework;
using Phantom;

namespace ConverterDefense
{
    public class Image : Component
    {
        private Sprite sprite;
        private int frame;
        private Vector2 position;
        private int pass;

        public Image(Sprite sprite)
            : this(sprite, 0, new Vector2(PhantomGame.Game.Width * 0.5f, PhantomGame.Game.Height * 0.5f), 0) { }

        public Image(Sprite sprite, int frame)
            : this(sprite, frame, new Vector2(PhantomGame.Game.Width * 0.5f, PhantomGame.Game.Height * 0.5f), 0) { }

        public Image(Sprite sprite, int frame, int pass)
            : this(sprite, frame, new Vector2(PhantomGame.Game.Width * 0.5f, PhantomGame.Game.Height * 0.5f), pass) { }

        public Image(Sprite sprite, Vector2 position)
            : this(sprite, 0, position, 0) { }

        public Image(Sprite sprite, int frame, Vector2 position)
            : this(sprite, frame, position, 0) { }

        public Image(Sprite sprite, int frame, Vector2 position, int pass)
        {
            this.sprite = sprite;
            this.frame = frame;
            this.position = position;
            this.pass = pass;
        }
        public override void Render(RenderInfo info)
        {
            base.Render(info);
            if (info.Pass == pass)
                sprite.RenderFrame(info, frame, position);
        }
    }
}
