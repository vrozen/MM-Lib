//What would you like to modify?

pool gold at 2000

Base
{
  pool brew
  pool msg
  pool beer

  pool brewCost at 10
  pool msgCost at 20
  pool beerCost at 30

  user converter gbrew
  user converter gMsg
  user converter gBeer

  buyOneCoffee: gold -brewCost-> gbrew
  getOneCoffee: gbrew --> brew
  
  buyOneMessage: gold -msgCost-> gMsg
  sndOneMessage: gMsg --> msg
  buyOneBeer: gold -beerCost-> gBeer
  getOneBeer: gBeer --> beer
  user all drain ubrew
  user all drain uBeer
  user all drain uMsg

  buyCoffeePackage: gold -100-> ubrew
  buyBeerPackege: gold -300-> uBeer
  buyMessagePackage: gold -200-> uMsg

  getCoffeePackage: brewCost -brewCost-> ubrew
  getBeerPackage:   beerCost -beerCost-> uBeer
  getMsgPackage:    msgCost -msgCost-> uMsg
}

modify //evaluating this modification changes the game

