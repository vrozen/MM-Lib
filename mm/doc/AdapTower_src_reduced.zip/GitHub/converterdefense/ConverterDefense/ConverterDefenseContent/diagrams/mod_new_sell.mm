//What would you like to modify?

Base
{
  user source sell
  drain sacrifice
  triggerSacrifice: sell .*.> sacrifice
  sacrificeSelf:  self --> sacrifice
  getGold4Self2:  sell -50-> gold


  user converter vent
  ventHeat: heat -10-> vent
  sellHeat: vent -10-> gold
}

modify //evaluating this modification changes the game
