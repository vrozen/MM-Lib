converterdefense
================

Experimental game that incorporates a Machinations diagram as source