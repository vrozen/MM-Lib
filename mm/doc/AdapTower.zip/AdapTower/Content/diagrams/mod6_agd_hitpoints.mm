//What would you like to modify?
Tower
{
  pool self at 5
}

modify //evaluating this modification changes the game
