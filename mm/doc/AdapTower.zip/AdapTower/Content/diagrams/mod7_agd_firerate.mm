//What would you like to modify?

Tower
{
  pool fireRate at 250
  user converter upgradeRate
  xp --> upgradeRate
  upgradeRate -100-> fireRate
}

modify //evaluating this modification changes the game
