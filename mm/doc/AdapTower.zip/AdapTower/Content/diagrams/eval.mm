Tower
{
  inout ref hp
  inout ref otherHp
  user pool get1
  user pool get2

  cond1: otherHp . (otherHp > 3) .> get2
  cond2: hp      . (hp > 4)      .> get1
  getHP: hp --> get1
  getOtherHp: otherHp --> get2
}

Player
{
  inout pool hp at 5
  inout ref otherHp
}

Player player

Player other

bindHp1: player.hp .=.> towers.hp
bindHp2: other.hp .=.> player.otherHp
bindHp3: player.otherHp .=.> towers.otherHp

modify
